#!/usr/bin/env python3
"""Agent Contract Kit 0.1.0. Offline, data-only package format; standard library.

Reads never create files. A write requires an exact, project-bound review ticket.
Nothing in this module is imported from the managed project or from a release.
"""
from __future__ import annotations

import argparse
import contextlib
import datetime as dt
import difflib
import errno
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import tempfile
import unicodedata
import uuid
from dataclasses import dataclass, field

VERSION = '0.1.35'
PREFIX = '.agent-contract/'
BASE = PREFIX + 'base/'
STATE = PREFIX + 'project/state.json'
CHECKS = PREFIX + 'project/checks.json'
LOCAL = PREFIX + 'local/'
# 0.1.31: записанные ответы модели — вход владельца, а не запись комплекта (И-051, §14 ур. 4).
MODELS = LOCAL + 'model/'
OPS = LOCAL + 'ops/'
ENTRY = 'AGENTS.md'
DATA = ('START.md', 'PROTOCOL.md', 'schema.json', 'rules.json', 'entry.txt')
FILES = ('manifest.json', *DATA)
# 0.1.35: ответ калибровки пишется комплектом, поэтому он входит в закрытый список путей (И-055).
CAL = LOCAL + 'calibration/answers.json'
TARGETS = frozenset((ENTRY, STATE, CHECKS, CAL, *(BASE + n for n in FILES)))
MAX_BYTES = 2 * 1024 * 1024
TYPES = ('contract', 'rule', 'constraint', 'protocol', 'preference')
TRANSITIONS = {'draft': ['active', 'revoked'], 'active': ['suspended', 'revoked'],
               'suspended': ['active', 'revoked'], 'revoked': []}
ENTRY_KEYS = 'id kind contract title state scope text basis criterion key value revision updated_at reason'
SEV = re.compile(r'(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\Z')
ID = re.compile(r'[BP]-[1-9][0-9]{0,11}\Z')
HEX = re.compile(r'[0-9a-f]{64}\Z')
TX = re.compile(r'[0-9a-f]{32}\Z')
ENV_KEYS = 'os editor editor_version extension extension_version mode model profile permissions'
NATIVE_HINTS = ('.github/copilot-instructions.md', '.github/instructions', 'kilo.jsonc', '.kilocode/rules',
                'CLAUDE.md', '.claude/CLAUDE.md', '.cursor/rules', 'GEMINI.md',
                'AGENT.md', '.kilo/kilo.jsonc', '.kilo/rules', '.kilocoderules',
                '.github/agents', '.github/prompts', '.github/skills', '.vscode/settings.json')


# --- 0.1.6: карточка среды (адаптер Kilo Code, И-026) -------------------------------
# Среда описана данными, а не поведением: что Kilo читает, в каком порядке старшинства, что комплект
# не имеет права трогать и что здесь не проверено. Источники сверены 18.11.2026:
#   https://kilo.ai/docs/customize/agents-md — вход, старшинство, защита файла, применение в новых задачах
#   https://deepwiki.com/Kilo-Org/kilocode/8.3-agent-rules-and-workflows — каталоги правил и подкаталоги
ADAPTERS = {
    'kilo': {
        'name': 'kilo',
        'title': 'Kilo Code',
        'entry': ENTRY,
        'entry_fallback': 'AGENT.md',
        'priority': {'rank': 3, 'of': 4, 'order': [
            {'rank': 1, 'source': 'agent prompt in config', 'ours': False},
            {'rank': 2, 'source': 'instructions key in project kilo.jsonc', 'ours': False},
            {'rank': 3, 'source': 'root AGENTS.md', 'ours': True},
            {'rank': 4, 'source': 'instructions key in global kilo.jsonc', 'ours': False}]},
        'sources': ['.kilo/kilo.jsonc', '.kilo/rules', '.kilocode/rules', '.kilocoderules', 'AGENT.md'],
        'never_writes': ['.kilo/', '.kilocode/', '.kilocoderules', 'kilo.jsonc'],
        'environment_facts': {'entry_is_write_protected': True, 'changes_apply_in_new_tasks': True,
                              'per_directory_agents_md_loaded_on_read': True},
        'not_proven': ['auto-discovery', 'content_was_read', 'behaviour_with_model'],
        'discovery_proven': False,
    },
}

# --- 0.1.15: обнаружение как данные (И-035, уровень достоверности 2) --------------------
# Порядок старшинства из карточек сред, приведённый к путям. Учитывается только наличие: содержимое
# конфигураций сред (например, ключ `instructions` внутри kilo.jsonc) не читается — это объявленный
# пробел, а не проверка. Глобальные уровни (личные и организационные инструкции) в проект не входят.
DISCOVERY_ORDER = {
    'kilo': [
        {'rank': 2, 'path': '.kilo/kilo.jsonc', 'source': 'instructions key in project kilo.jsonc',
         'limits': 'проверяется только наличие файла, ключ внутри не читается'},
        {'rank': 3, 'path': ENTRY, 'source': 'root AGENTS.md', 'limits': None},
    ],
    'copilot': [
        {'rank': 2, 'path': '.github/instructions', 'source': 'path-specific *.instructions.md',
         'limits': 'каталог с applyTo-файлами; содержимое не читается'},
        {'rank': 3, 'path': '.github/copilot-instructions.md', 'source': 'repository instructions',
         'limits': None},
        {'rank': 4, 'path': ENTRY, 'source': 'AGENTS.md (agent instructions)', 'limits': None},
    ],
}


def discovery(root, name):
    """0.1.15: что найдено и что среда прочитает первой — по объявленному порядку, без живых сред."""
    card = ADAPTERS.get(name)
    need(card is not None, 'adapter_unknown', 'Неизвестная среда: карточка не выдаётся.',
         sorted(ADAPTERS))
    need(card.get('status') == 'documented', 'adapter_stub',
         'Карточка-заглушка: порядок обнаружения не сверялся, отвечать нечем.', {'environment': name})
    present = {h['path']: h['kind'] for h in native_hints(root)}
    try:
        st = safe(root, ENTRY).lstat()
        present[ENTRY] = 'directory' if stat.S_ISDIR(st.st_mode) else 'file'
    except FileNotFoundError:
        pass
    order, chosen = [], None
    for step in DISCOVERY_ORDER[name]:
        found = step['path'] in present
        order.append({'rank': step['rank'], 'path': step['path'], 'source': step['source'],
                      'present': found, 'kind': present.get(step['path']), 'limits': step['limits']})
        if found and chosen is None:
            chosen = step['path']
    others = sorted(p for p in present if p not in {s['path'] for s in DISCOVERY_ORDER[name]})
    return {'environment': name, 'title': card['title'], 'entry': ENTRY,
            'found': sorted(present), 'order': order, 'chosen': chosen,
            'chosen_rank': next((o['rank'] for o in order if o['path'] == chosen), None),
            'entry_present': ENTRY in present, 'contract_installed': read(root, STATE) is not None,
            'other_hints': others,
            'levels': {'1_file_present': 'pass' if present else 'fail',
                       '2_environment_found': 'not run', '3_content_read': 'not run',
                       '5_behavior_repeatable': 'not run'},
            'measured': ['file_present', 'names'], 'declared_only': ['environment_found', 'content_read'],
            'contents_read': False, 'discovery_proven': False, 'writes': False,
            'note': 'Это обнаружение по документированному порядку, а не проверка живой среды: '
                    'уровни 2, 3 и 5 не измерялись. Содержимое чужих файлов не читается.'}


# 0.1.29: metrics, due и rights — тоже чтение; они появились позже и в список не попали (И-049, F48).
READ_ONLY = ('status', 'list', 'history', 'removed', 'updates', 'pending', 'operations', 'inventory',
             'adapter', 'brief', 'identity', 'discovery', 'entry', 'session', 'metrics', 'due', 'rights',
             'system', 'model', 'verify', 'layout', 'access', 'calibrate')


def canonical_facts(facts):
    """Каноническая форма фактов: ключи по возрастанию, UTF-8, без пробелов."""
    need(type(facts) is dict, 'answer', 'facts — объект ключ-значение.')
    for key, value in facts.items():
        need(type(key) is str and key != '', 'answer', 'Ключ факта — непустая строка.')
        need(value is None or isinstance(value, (str, bool, int, float)), 'answer',
             'Значение факта — строка, число, булево или null.', {'key': key})
    return json.dumps(facts, sort_keys=True, separators=(',', ':'), ensure_ascii=False)


def facts_digests(facts):
    """Отпечатки по полям: значение не хранится, сверяется только отпечаток."""
    return {key: hashlib.sha256(canonical_facts({key: value}).encode('utf-8')).hexdigest()
            for key, value in facts.items()}


def calibration_book(lab):
    path = Path(lab) / 'kit/calibration.json'
    need(path.is_file(), 'no_calibration', 'В поставке нет kit/calibration.json.')
    book = parse(path.read_bytes())
    need(book.get('schema_version') == 1, 'calibration', 'Неизвестная схема калибровки.')
    need([item.get('id') for item in book.get('prompts', [])] == ['K1', 'K2', 'K3', 'K4'], 'calibration',
         'Промпты калибровки — ровно K1…K4 по порядку.')
    return book


def answers_book(root):
    raw = read(Path(root), CAL)
    if raw is None:
        return {'schema_version': 1, 'answers': []}
    book = parse(raw)
    need(type(book.get('answers')) is list, 'answer', 'Файл ответов повреждён.')
    return book


def compare_answer(book, prompt, answer, attempts):
    need(type(answer) is dict, 'answer', 'Ответ — объект.')
    unknown = set(answer) - set('prompt system_version schema_version environment facts not_run manual verdict_self'.split())
    need(not unknown, 'answer', 'Лишние поля в ответе.', {'unknown': sorted(unknown)})
    need(answer.get('prompt') == prompt['id'], 'answer', 'В ответе другой промпт.', {'expected': prompt['id']})
    need(answer.get('schema_version') == book['schema_version'], 'answer', 'Схема ответа не совпадает.')
    facts = answer.get('facts')
    need(type(facts) is dict, 'answer', 'facts — объект.')
    known = {item['key'] for item in prompt['facts']}
    extra = sorted(set(facts) - known)
    missing = sorted(known - set(facts))
    fields = {}
    for item in prompt['facts']:
        key = item['key']
        if key in missing:
            fields[key] = 'missing'
        else:
            got = hashlib.sha256(canonical_facts({key: facts[key]}).encode('utf-8')).hexdigest()
            fields[key] = 'equal' if got == item['digest'] else 'mismatch'
    for key in extra:
        fields[key] = 'extra'
    matched = all(value == 'equal' for value in fields.values())
    reason = None
    if not matched:
        reason = 'data' if any(value in ('mismatch', 'missing') for value in fields.values()) else 'shape'
    not_run = answer.get('not_run') or []
    manual = answer.get('manual') or []
    need(type(not_run) is list and type(manual) is list, 'answer', 'not_run и manual — списки.')
    next_step = ('done' if matched else
                 'repeat' if reason == 'data' and attempts < 2 else 'manual')
    return {'prompt': prompt['id'], 'match': matched, 'fields': fields, 'reason': reason,
            'facts_digest': hashlib.sha256(canonical_facts(facts).encode('utf-8')).hexdigest(),
            'environment': answer.get('environment'), 'attempts': attempts, 'next': next_step,
            'not_run': not_run, 'manual': manual, 'writes': False,
            'verdict_note': 'Вердикт считается только по facts. Проза (not_run, manual) объясняет человеку, '
                            'но не влияет на match.'}


FIX_KINDS = ('checks', 'temp')


def fix_plan(root, kind):
    """Закрытый список безопасных починок (И-055, §3.5)."""
    need(kind in FIX_KINDS, 'fix_kind', 'Починка вне закрытого списка.', {'allowed': list(FIX_KINDS)})
    changes = {}
    if kind == 'checks':
        raw = read(Path(root), CHECKS)
        need(raw is not None, 'nothing', 'Файла журнала проверок нет.', {'manual': 'запустите install'})
        book = parse(raw)
        need(type(book.get('checks')) is list, 'nothing', 'Журнал проверок повреждён — это ручная работа.')
        fixed = encode(book)
        if fixed != raw:
            changes[CHECKS] = fixed
    if kind == 'temp':
        local = Path(root) / LOCAL
        if local.is_dir():
            for path in sorted(local.rglob('*')):
                if path.is_file() and (path.name.endswith('.tmp') or '.probe-' in path.name
                                       or path.name.startswith('.probe-')):
                    changes[path.relative_to(Path(root)).as_posix()] = None
    return changes


def tree_digest(root):
    """0.1.17: отпечаток собственных данных проекта — чтобы повтор ничего не менял."""
    base = safe(root, '.agent-contract')
    parts = []
    for dirpath, dirnames, filenames in os.walk(base):
        dirnames.sort()
        for name in sorted(filenames):
            path = Path(dirpath) / name
            parts.append(path.relative_to(root).as_posix() + ':' + digest(path.read_bytes()))
    return digest('\n'.join(parts).encode())


MODEL_TASKS = ('explain', 'choose', 'refuse')


def norm_text(s):
    """0.1.31: сравнение ответа модели по словам, а не по типографике (И-051)."""
    return ' '.join((s or '').split())


def reader_state(records, entry, retired):
    """0.1.31: состояние правила глазами читателя — active, hidden, draft, suspended, revoked (И-051)."""
    if retired:
        return 'retired'
    if entry['state'] == 'active' and records[entry['contract']]['state'] != 'active':
        return 'hidden'
    return entry['state']


def grade_answer(records, retired, answer):
    """0.1.31: ответ модели оценивается как данные, а не как поведение (И-051, §14 ур. 4)."""
    need(isinstance(answer, dict), 'answer', 'Ответ модели — объект JSON.')
    claims = answer.get('claims')
    need(isinstance(claims, list) and claims, 'answer',
         'В ответе нет утверждений: оценивать нечего.',
         {'expected': 'claims: [{id, state, text}]'})
    graded = []
    for item in claims:
        need(isinstance(item, dict) and isinstance(item.get('id'), str), 'answer',
             'Утверждение без идентификатора правила.', {'claim': item})
        ident = item['id']
        entry = records.get(ident)
        if entry is None or entry['kind'] == 'contract':
            graded.append({'id': ident, 'verdict': 'fail', 'why': 'unknown_rule',
                           'claimed': {'state': item.get('state'), 'text': item.get('text')},
                           'measured': None})
            continue
        measured = reader_state(records, entry, retired)
        claimed_state = item.get('state')
        claimed_text = item.get('text')
        row = {'id': ident, 'claimed': {'state': claimed_state, 'text': claimed_text},
               'measured': {'state': measured, 'title': entry['title'], 'scope': entry['scope']}}
        if claimed_state is not None and claimed_state != measured:
            row.update(verdict='fail', why='state_mismatch')
            graded.append(row)
            continue
        if claimed_text is not None and norm_text(claimed_text) != norm_text(entry.get('text')):
            row.update(verdict='fail', why='text_mismatch')
            graded.append(row)
            continue
        row.update(verdict='pass', why='same')
        graded.append(row)
    failed = [r for r in graded if r['verdict'] == 'fail']
    return {'answer': {'model': answer.get('model'), 'at': answer.get('at'), 'task': answer.get('task')},
            'claims': graded, 'counts': {'pass': len(graded) - len(failed), 'fail': len(failed)},
            'verdict': 'fail' if failed else 'pass',
            'checked_against': 'реестр и состояния: active, hidden, draft, suspended, revoked',
            'live': False, 'writes': False,
            'note': 'Модель не вызывалась и не будет: проверен записанный ответ. Уровень «модель прочитала» '
                    'остаётся not run, уровень «поведение проверяемо» измерен на записи.'}


def case_conflicts(root, paths):
    """0.1.30: имена, совпадающие без учёта регистра, на NTFS — один файл (И-050, §16)."""
    found = []
    for path in paths:
        parent_rel, _, name = path.rpartition('/')
        if not parent_rel:
            folder = Path(root)
        elif (Path(root) / parent_rel).is_dir():
            folder = safe(root, parent_rel)
        else:
            continue
        try:
            entries = sorted(folder.iterdir())
        except OSError:
            continue
        for entry in entries:
            if entry.name != name and entry.name.casefold() == name.casefold():
                found.append({'path': path, 'existing': entry.relative_to(root).as_posix()})
    return found


def foreign_files(root):
    """0.1.29: файлы в служебном каталоге, которых комплект не создавал (И-049, §11)."""
    folder = PREFIX.rstrip('/')
    if not (Path(root) / folder).is_dir():
        return []
    base = safe(root, folder)
    # checks.incoming.json — объявленный вход операции merge: чужой по автору, но не посторонний.
    allowed = {BASE + n for n in FILES} | {STATE, CHECKS, PREFIX + 'project/checks.incoming.json'}
    found = []
    for dirpath, _dirnames, filenames in os.walk(base):
        for name in filenames:
            rel_path = (Path(dirpath) / name).relative_to(root).as_posix()
            if rel_path.startswith(LOCAL) or rel_path in allowed:
                continue
            found.append(rel_path)
    return sorted(found)


def guard_writes(root):
    """0.1.29: посторонняя запись останавливает изменения, а не притворяется своей (И-049)."""
    foreign = foreign_files(root)
    need(not foreign, 'foreign', 'В служебном каталоге есть посторонние записи: изменения остановлены.',
         {'foreign': foreign,
          'fix': 'уберите файлы или верните проект операцией restore, затем повторите'})


def repeat_reads(lab, project, root, runs, requests):
    """0.1.17: серия чтений. Повтор ответа, а не поведения: так и сказано в ответе."""
    need(type(runs) is int and 2 <= runs <= 9, 'runs', 'Повтор: от 2 до 9 прогонов.')
    need(type(requests) is list and 1 <= len(requests) <= 8, 'requests', 'Нужен список из 1–8 запросов.')
    checked = []
    for item in requests:
        exact(item, 'command', 'payload')
        need(item['command'] in READ_ONLY, 'repeat_write',
             'Повтор допускает только команды чтения.', {'allowed': list(READ_ONLY)})
        payload = item.get('payload') or {}
        need(type(payload) is dict, 'request', 'Поля запроса — объект JSON.')
        checked.append((item['command'], payload))
    before = tree_digest(root)
    answers = []
    for command, payload in checked:
        outs = [encode(dispatch(lab, project, command, payload)) for _ in range(runs)]
        answers.append({'command': command, 'identical': len(set(outs)) == 1,
                        'runs': runs, 'differing': [] if len(set(outs)) == 1 else 1})
    after = tree_digest(root)
    return {'runs': runs, 'requests': answers, 'identical': all(a['identical'] for a in answers),
            'project_unchanged': before == after, 'volatile': ['operation time', 'file mtime'],
            'behavior_proven': False, 'writes': False,
            'note': 'Повтор ответа комплекта измерен; повтор поведения модели — not run.'}


class Refusal(Exception):
    def __init__(self, code, message, details=None):
        super().__init__(message)
        self.code, self.details = code, details


def need(ok, code, message, details=None):
    if not ok:
        raise Refusal(code, message, details)


def exact(obj, required, optional=''):
    need(isinstance(obj, dict), 'format', 'Ожидается объект JSON.')
    required, optional = set(required.split()), set(optional.split())
    missing, unknown = required - obj.keys(), obj.keys() - required - optional
    need(not (missing or unknown), 'fields', 'Поля не соответствуют формату. Запись запрещена.',
         {'missing': sorted(missing), 'unknown': sorted(unknown)})


def string(s, field_name='text', maximum=16384):
    need(type(s) is str and 0 < len(s) <= maximum and s.strip() and '\x00' not in s,
         'field', f'Нужно непустое текстовое поле: {field_name}.')
    return s


def integer(n, low=0):
    return type(n) is int and low <= n <= 10**12


def digest(b):
    return None if b is None else hashlib.sha256(b).hexdigest()


def encode(obj):
    return (json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n').encode('utf-8')


def parse(b):
    def unique(pairs):
        obj = {}
        for name, value in pairs:
            need(name not in obj, 'duplicate_key', 'Повторяющееся имя поля JSON.', {'field': name})
            obj[name] = value
        return obj
    def reject(_):
        raise Refusal('json', 'Нечисловые константы запрещены.')
    try:
        need(len(b) <= MAX_BYTES, 'limit', 'Слишком большой документ.')
        obj = json.loads(b.decode('utf-8-sig'), object_pairs_hook=unique, parse_constant=reject)
        # Reject unpaired Unicode surrogates rather than failing midway through a write.
        json.dumps(obj, ensure_ascii=False, allow_nan=False).encode('utf-8')
        return obj
    except (ValueError, UnicodeError, RecursionError) as exc:
        raise Refusal('json', 'Неверный JSON или кодировка UTF-8.') from exc


def timestamp():
    return dt.datetime.now(dt.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')


def date_ok(s):
    try:
        return type(s) is str and bool(re.fullmatch(r'\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ', s)) and bool(dt.datetime.strptime(s, '%Y-%m-%dT%H:%M:%SZ'))
    except ValueError:
        return False


def rel(s, dot=False):
    string(s, 'path', 1024)
    if dot and s == '.':
        return s
    for p in s.split('/'):
        need(p not in ('', '.', '..') and p.lower() not in ('.git', '.isai', '.env') and
             not p.lower().startswith('.env.') and not p.endswith(('.', ' ')) and
             not re.search(r'[\\:"<>|?*\x00-\x1f]', p) and
             not re.fullmatch(r'(CON|PRN|AUX|NUL|COM[1-9¹²³]|LPT[1-9¹²³])', p.split('.')[0], re.I),
             'path', 'Недопустимый относительный путь.', {'path': s})
        # 0.1.30: имя длиннее 255 байт не создаётся ни на POSIX, ни на NTFS (И-050, §16).
        need(len(p.encode('utf-8')) <= 255, 'path', 'Имя длиннее 255 байт: файловая система его не примет.',
             {'path': s, 'part': p, 'bytes': len(p.encode('utf-8')), 'limit': 255})
    return s


def fscheck(p):
    """Check all existing components, including the selected root. No link traversal."""
    for q in (*reversed(p.parents), p):
        try:
            st = q.lstat()
        except FileNotFoundError:
            break
        isdir = stat.S_ISDIR(st.st_mode)
        need(not stat.S_ISLNK(st.st_mode) and not (getattr(st, 'st_file_attributes', 0) & 0x400),
             'boundary', 'Ссылка или reparse point: операция остановлена.', {'path': str(q)})
        need(isdir or (q == p and stat.S_ISREG(st.st_mode) and st.st_nlink == 1),
             'boundary', 'Необычный файл, hard link или файл вместо каталога.', {'path': str(q)})
    return p


def safe(root, name):
    rel(name, dot=True)
    p = root if name == '.' else root.joinpath(*name.split('/'))
    return fscheck(p)


def labroot(arg):
    spelling = os.fspath(arg)
    need(not spelling.replace(chr(92), '/').startswith('//'), 'root', 'Сетевые пути и пути устройств не поддерживаются.')
    p = Path(arg)
    need(p.is_absolute() and '..' not in p.parts and p != Path(p.anchor), 'root', 'Нужен абсолютный путь к отдельному каталогу, не корень диска.')
    for component in p.parts[1:]:
        rel(component)
    if os.name == 'nt':
        import ctypes
        from ctypes import wintypes
        drive_type = ctypes.windll.kernel32.GetDriveTypeW
        drive_type.argtypes, drive_type.restype = [wintypes.LPCWSTR], wintypes.UINT
        need(drive_type(p.anchor) in (2, 3, 6), 'root', 'Нужен подтверждённый локальный том.')
    fscheck(p)
    need(p.is_dir(), 'root', 'Лаборатория не найдена.')
    return p


def read(root, name, *, required=False):
    p = safe(root, name)
    try:
        with p.open('rb') as f:
            b = f.read(MAX_BYTES + 1)
    except FileNotFoundError:
        need(not required, 'missing', 'Нет необходимого файла.', {'path': name})
        return None
    need(len(b) <= MAX_BYTES, 'limit', 'Файл превышает лимит.', {'path': name})
    return b


def native_hints(root):
    # Closed list, metadata only; never enumerate these directories or open their files.
    result = []
    for name in NATIVE_HINTS:
        try:
            st = safe(root, name).lstat()
        except FileNotFoundError:
            continue
        except Refusal as exc:
            if exc.code != 'boundary':
                raise
            result.append({'path': name, 'kind': 'inaccessible_boundary'})
            continue
        result.append({'path': name, 'kind': 'directory' if stat.S_ISDIR(st.st_mode) else 'file',
                       'size': st.st_size, 'mtime_ns': st.st_mtime_ns})
    return result


def flushdir(p):
    if os.name != 'nt' and hasattr(os, 'O_DIRECTORY'):
        fd = os.open(p, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)


def mkdirs(p):
    fscheck(p)
    if not p.is_dir():
        mkdirs(p.parent)
        p.mkdir(exist_ok=True)
        fscheck(p)
        flushdir(p.parent)


def put(root, name, data):
    p = safe(root, name)
    if data is None:
        p.unlink()  # caller must have a separately approved deletion in the exact plan
        flushdir(p.parent)
        return
    need(len(data) <= MAX_BYTES, 'limit', 'Результат превышает лимит файла.')
    mkdirs(p.parent)
    fd, tmp = tempfile.mkstemp(prefix='.contract-tmp-', dir=p.parent)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        fscheck(p)
        os.replace(tmp, p)
        flushdir(p.parent)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)  # our own uncommitted staging file only


@contextlib.contextmanager
def writer(root, name=LOCAL + 'writer.lock'):
    p = safe(root, name)
    mkdirs(p.parent)
    with p.open('a+b') as handle:
        handle.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (ImportError, OSError) as exc:
            raise Refusal('writer_busy', 'Не получена межпроцессная блокировка. Запись запрещена.') from exc
        try:
            yield
        finally:
            if os.name == 'nt':
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(handle, fcntl.LOCK_UN)


def schema_doc():
    return {'format': 'agent-contract-fields', 'schema_version': 1, 'kinds': list(TYPES),
            'fields': ENTRY_KEYS.split(), 'transitions': TRANSITIONS, 'scope': '. or relative subtree',
            'structured_conflict': 'equal non-null key + unequal value in intersecting effective scopes'}


def within(child, parent):
    child, parent = child.casefold(), parent.casefold()
    return parent == '.' or child == parent or child.startswith(parent + '/')


def registry(base, project):
    result = {}
    for prefix, records in [('B', base), ('P', project)]:
        need(type(records) is list and len(records) <= 4096, 'registry', 'Некорректный список записей.')
        for e in records:
            exact(e, ENTRY_KEYS, 'owner review_days reviewed_at review_by')
            # 0.1.23: срок проверки — дата в записи, а не память участника (И-043, §10.3).
            for name in ('reviewed_at', 'review_by'):
                need(e.get(name) is None or date_ok(e[name]), 'review', 'Срок проверки — дата.',
                     {'field': name})
            need(e.get('review_days') is None or (integer(e['review_days'], 1) and e['review_days'] <= 3650),
                 'review_days', 'Срок проверки — целое от 1 до 3650 дней.')
            # 0.1.22: владелец назван в данных, иначе «кто вправе» остаётся догадкой (И-042, §10.1).
            if 'owner' in e:
                need(e['owner'] is None or (type(e['owner']) is str and 0 < len(e['owner']) <= 64
                                            and e['owner'].strip() == e['owner']), 'owner',
                     'Владелец — строка до 64 символов без крайних пробелов или null.')
            i = string(e['id'], 'id')
            need(ID.fullmatch(i) and i.startswith(prefix + '-') and i not in result, 'id', 'Неверный или повторяющийся ID.', {'id': i})
            need(e['kind'] in TYPES and type(e['state']) is str and e['state'] in TRANSITIONS, 'state', 'Неизвестный вид или состояние записи.')
            rel(e['scope'], dot=True)
            for k in ('title', 'text', 'basis', 'criterion', 'reason'):
                string(e[k], k)
            need(integer(e['revision'], 1) and date_ok(e['updated_at']), 'revision', 'Неверная версия или дата записи.')
            need((e['key'] is None and e['value'] is None) or
                 (type(e['key']) is str and re.fullmatch(r'[a-z][a-z0-9_.-]{0,63}', e['key']) and string(e['value'], 'value', 1024)),
                 'key', 'Ключ сравнения и его строковое значение задаются вместе.')
            if e['kind'] == 'contract':
                need(e['contract'] is None and e['key'] is None, 'parent', 'У контракта нет родителя и ключа сравнения.')
            else:
                need(type(e['contract']) is str, 'parent', 'Запись должна принадлежать контракту.')
            result[i] = e
    for e in result.values():
        if e['contract'] is not None:
            parent = result.get(e['contract'])
            need(parent and parent['kind'] == 'contract' and within(e['scope'], parent['scope']) and
                 not (e['id'].startswith('B-') and not parent['id'].startswith('B-')), 'parent',
                 'Отсутствует контракт или область выходит за его границы.', {'id': e['id'], 'parent': e['contract']})
    return result


def effective(records, target=None):
    if target is not None:
        rel(target, dot=True)
    return [e for e in records.values() if e['kind'] != 'contract' and e['state'] == 'active'
            and records[e['contract']]['state'] == 'active' and (target is None or within(target, e['scope']))]


def contradictions(records):
    groups = {}
    problems = []
    for e in effective(records):
        if e['key'] is None:
            continue
        group = groups.setdefault(e['key'], [])
        for other in group:
            if other['value'] != e['value'] and (within(e['scope'], other['scope']) or within(other['scope'], e['scope'])):
                problems.append([{k: x[k] for k in ('id', 'key', 'value', 'scope', 'text')} for x in (other, e)])
                if len(problems) >= 32:
                    return problems
        group.append(e)
    return problems


def manifest_check(raw):
    m = parse(raw)
    exact(m, 'format schema_version base_version origin adapter_version files')
    need(m['format'] == 'agent-contract-release' and integer(m['schema_version'], 1) and m['schema_version'] == 1,
         'schema', 'Неподдерживаемая схема выпуска: только чтение.')
    need(SEV.fullmatch(string(m['base_version'], 'version', 32)) and integer(m['adapter_version'], 1), 'version', 'Неверная версия.')
    string(m['origin'], 'origin')
    need(type(m['files']) is dict and set(m['files']) == set(DATA) and
         all(HEX.fullmatch(string(h, 'sha256', 64)) for h in m['files'].values()), 'manifest', 'Состав выпуска не соответствует разрешённому списку.')
    return m


def base_check(files):
    need(encode(parse(files['schema.json'])) == encode(schema_doc()), 'schema', 'Неизвестное описание схемы. Интерпретация запрещена.')
    obj = parse(files['rules.json'])
    exact(obj, 'schema_version entries')
    need(type(obj['schema_version']) is int and obj['schema_version'] == 1, 'schema', 'Неизвестная схема базовых записей.')
    records = registry(obj['entries'], [])
    issues = contradictions(records)
    need(not issues, 'conflict', 'Противоречивые активные базовые правила.', issues)
    for name in ('START.md', 'PROTOCOL.md', 'entry.txt'):
        try:
            text = files[name].decode('utf-8')
        except UnicodeError as exc:
            raise Refusal('encoding', 'Требуется UTF-8.', {'path': name}) from exc
        need(bool(text.strip()) and '\x00' not in text, 'base_text', 'Пустой или бинарный документ базы.')
    return obj['entries']


def package(lab, folder, pin):
    rel(folder)
    need(re.fullmatch(r'releases/(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)', folder), 'package_path', 'Используйте локальный releases/<версия>.')
    root = safe(lab, folder)
    raw = read(root, 'manifest.json', required=True)
    need(type(pin) is str and HEX.fullmatch(pin) and digest(raw) == pin, 'trust', 'Отпечаток не совпадает с отдельно одобренным выпуском.')
    m = manifest_check(raw)
    need('releases/' + m['base_version'] == folder, 'version', 'Имя каталога и версия выпуска различаются.')
    files = {'manifest.json': raw}
    for name in DATA:
        b = read(root, name, required=True)
        need(digest(b) == m['files'][name], 'integrity', 'Содержимое не совпадает с отпечатком выпуска.', {'path': name})
        files[name] = b
    base_check(files)
    inspect_links(files)
    return files, m


def baseline(m, files):
    return {'version': m['base_version'], 'pin': digest(files['manifest.json']), 'origin': m['origin'],
            'installed': {name: digest(files[name]) for name in DATA}}


def check_state(s):
    need(isinstance(s, dict) and type(s.get('schema_version')) is int, 'schema', 'Схема проекта не названа числом.')
    if s['schema_version'] != 1:
        # 0.1.24: неизвестная версия — отказ с ответом «что нашлось и чем вернуться» (И-044, §12.2).
        raise Refusal('unknown_schema',
                      'Схема проекта этой версии неизвестна: данные не переписаны, миграции для неё нет. '
                      'Вернуться к прежнему состоянию можно копией проекта или файлом before из журнала операции.',
                      {'found': s['schema_version'], 'supported': [1], 'migrate': False,
                       'recover': ['копия проекта', 'local/ops/<tx>/before/' + STATE.split('/')[-1]]})
    exact(s, 'schema_version revision next_id entries decisions base adapter retired', 'tombstones')
    need(integer(s['revision']) and integer(s['next_id'], 1) and type(s['retired']) is bool, 'state', 'Неверное состояние проекта.')
    exact(s['base'], 'version pin origin installed')
    need(SEV.fullmatch(string(s['base']['version'], 'version', 32)) and HEX.fullmatch(string(s['base']['pin'])), 'version', 'Неверная привязка базы.')
    string(s['base']['origin'], 'origin')
    hashes = s['base']['installed']
    need(isinstance(hashes, dict) and set(hashes) == set(DATA) and all(HEX.fullmatch(string(h)) for h in hashes.values()), 'integrity', 'Неверные отпечатки установки.')
    if s['adapter'] is not None:
        exact(s['adapter'], 'path version sha256')
        need(s['adapter']['path'] == ENTRY and integer(s['adapter']['version'], 1) and HEX.fullmatch(string(s['adapter']['sha256'])), 'adapter', 'Неверная запись адаптера.')
    need(type(s['entries']) is list and type(s['decisions']) is list and len(s['decisions']) == s['revision'], 'history', 'Разрыв в истории ревизий.')
    for n, d in enumerate(s['decisions'], 1):
        exact(d, 'revision at op reason subject', 'changes')
        for c in d.get('changes', []):
            exact(c, 'field before after')
            string(c['field'], 'field')
            for k in ('before', 'after'):
                need(c[k] is None or type(c[k]) is str, 'history', 'Неверное значение «до/после».')
        need(integer(d['revision'], 1) and d['revision'] == n and date_ok(d['at']), 'history', 'Неверная ревизия решения.')
        for k in ('op', 'reason', 'subject'):
            string(d[k], k)
    for e in s['entries']:
        need(type(e) is dict and ID.fullmatch(string(e.get('id'), 'id')) and int(e['id'].split('-')[1]) < s['next_id'], 'id', 'Нарушен счётчик ID.')
    for t in s.get('tombstones', []):
        need(type(t) is dict, 'removed', 'След удаления — объект.')
        exact(t, 'id kind contract scope title at reason revision')
        need(ID.fullmatch(string(t['id'], 'id')) and t['kind'] in TYPES, 'removed', 'Неверный след удаления.')
        need(date_ok(t['at']) and integer(t['revision'], 1), 'removed', 'Неверное время или ревизия следа.')
        for k in ('scope', 'title', 'reason'):
            string(t[k], k)
        need(t['contract'] is None or type(t['contract']) is str, 'removed', 'Родитель следа — строка или null.')
    need(not ({t['id'] for t in s.get('tombstones', [])} & {e['id'] for e in s['entries']}), 'removed',
         'Идентификатор не может быть одновременно удалён и занят.')


def check_results(raw):
    data = parse(raw)
    exact(data, 'schema_version checks')
    need(type(data['schema_version']) is int and data['schema_version'] == 1 and type(data['checks']) is list, 'schema', 'Неизвестный формат проверок.')
    for item in data['checks']:
        exact(item, 'at revision base_version adapter_version observation')
        need(date_ok(item['at']) and integer(item['revision']) and SEV.fullmatch(string(item['base_version'])) and
             (item['adapter_version'] is None or integer(item['adapter_version'], 1)), 'check', 'Некорректный контекст проверки.')
        observation(item['observation'])
    return data


def observation(o):
    exact(o, 'case level conditions expected actual status evidence limits environment')
    need(o['status'] in ('pass', 'fail', 'not run', 'inconclusive') and integer(o['level'], 1) and o['level'] <= 5, 'check', 'Неверный статус или уровень наблюдения.')
    for k in ('case', 'conditions', 'expected', 'limits'):
        string(o[k], k)
    for k in ('actual', 'evidence'):
        need(type(o[k]) is str and len(o[k]) <= 16384, 'check', 'Ожидается краткая запись наблюдения.')
        if o['status'] in ('pass', 'fail'):
            string(o[k], k)
    exact(o['environment'], ENV_KEYS)
    for k in ENV_KEYS.split():
        string(o['environment'][k], k)


# --- 0.1.4: смысловая тождественность наблюдений -----------------------------------
# Допуск измерен на замороженном корпусе (исследование И-020, 112 пар): критические поля и факты
# совпадают точно, смысловые фразы совпадают как набор признаков, а свободный текст может отличаться
# не более чем одним содержательным словом на поле и только если это слово совпадает посимвольно
# не менее чем на 85 %. Добавленное слово — уже другое наблюдение, даже если это «прогон повторён».
_TEXT_FIELDS = ('actual', 'evidence', 'limits', 'conditions')
_CRITICAL = ('case', 'level', 'status', 'expected', 'environment')
_GUARDS = ('не ', 'нет ', 'без ', 'только ', 'исключительно ', 'по памяти', 'со слов', 'не открывался',
           'не проверял', 'предполож', 'возможно', 'вероятно', 'кажется', 'похоже')
_PUNCT = re.compile(r'[^\w\s]+', re.UNICODE)
_SPACE = re.compile(r'\s+')
_WORD = re.compile(r'\w+', re.UNICODE)
_IDENT = re.compile(r'[A-Za-z_][A-Za-z0-9_.]*\d*')
_NUMBER = re.compile(r'\d+')
_FILE = re.compile(r'^\s*\S+\.(?:log|txt|json|md|csv|xml|ya?ml)\b[,;]?\s*', re.IGNORECASE)
_LINE = re.compile(r',?\s*строк[аиуе]?\s*\d+', re.IGNORECASE)
_TIME = re.compile(r'\b\d+(?:[.,]\d+)?\s*(?:ms|s|sec|secs|min|mins|мс|сек|мин|с)\b'
                   r'|\(\d+:\d{2}:\d{2}\)|\b\d{1,2}:\d{2}:\d{2}\b', re.IGNORECASE)
_STOP = frozenset('и в во на с со по при для от до из или это тот же как что the a of to in and'.split())
_SUFFIX = ('ами', 'ями', 'ов', 'ев', 'ий', 'ый', 'ая', 'ое', 'ые', 'ой', 'ем', 'ом', 'ах', 'ях',
           'ет', 'ут', 'ют', 'ит', 'ат', 'ят', 'ся', 'сь', 'а', 'я', 'о', 'е', 'и', 'ы', 'у', 'ю')


def plain(text):
    """Нижний регистр, ё→е, без пунктуации, одиночные пробелы."""
    text = unicodedata.normalize('NFKC', str(text)).lower().replace('ё', 'е')
    return _SPACE.sub(' ', _PUNCT.sub(' ', text)).strip()


def body(o, key):
    """Содержание поля: из улики убирается место, из всех полей — изменчивое время.

    Место (журнал и номер строки) — происхождение записи, а не её содержание: два прогона
    одного события не могут иметь одно место. Длительности и отметки времени — не факт события.
    Всё остальное в улике (например, отпечаток файла) остаётся содержанием и защищено.
    """
    text = str(o[key])
    if key == 'evidence':
        text = _LINE.sub('', _FILE.sub('', text))
    return _TIME.sub(' ', text).strip()


def guard_bits(o):
    """Закрытый лексикон смысла: наличие каждой фразы — признак, сравнение по набору."""
    text = ' ' + plain(' '.join(body(o, k) for k in _TEXT_FIELDS + ('expected',))) + ' '
    return frozenset(p for p in _GUARDS if p in text)


def fact_bits(o):
    """Идентификаторы и целые числа: изменённый факт запрещает склейку."""
    text = ' '.join([body(o, k) for k in _TEXT_FIELDS] + [str(o['expected']), str(o['case'])])
    # 0.1.10: завершающая точка — пунктуация предложения, а не часть идентификатора. Точка внутри
    # имени (`a.b`, `test_build.py`) остаётся значимой: strip снимает только завершающие точки.
    return (frozenset(m.rstrip('.').lower() for m in _IDENT.findall(text))
            | frozenset(_NUMBER.findall(text)))


def stem(word):
    for suffix in _SUFFIX:
        if len(word) - len(suffix) >= 4 and word.endswith(suffix):
            return word[:-len(suffix)]
    return word


def content(text):
    """Содержательные слова без служебных, усечённые до основы."""
    return frozenset(stem(w) for w in _WORD.findall(plain(text)) if w not in _STOP and len(w) > 1)


def word_deviation(a, b):
    """(сколько содержательных слов различается, худшее посимвольное сходство различающихся пар)."""
    left, right = content(a) - content(b), content(b) - content(a)
    if not left and not right:
        return 0, 1.0
    if not left or not right:
        return max(len(left), len(right)), 0.0
    worst = 1.0
    for x in sorted(left):
        worst = min(worst, max(difflib.SequenceMatcher(None, x, y).ratio() for y in sorted(right)))
    return max(len(left), len(right)), worst


def same_observation(a, b):
    """Одно и то же наблюдение: критическое равенство, факты, смысловые фразы, допуск на слово."""
    if a == b:
        return True
    for key in _CRITICAL:
        if key == 'environment':
            # 0.1.9: наблюдатель (редактор, расширение, версии, профиль) — происхождение записи,
            # как место улики в 0.1.5. Две среды видят одно событие — это одно наблюдение.
            for part in CONDITIONS:
                if str(a[key].get(part)) != str(b[key].get(part)):
                    return False
        elif a[key] != b[key]:
            return False
    if guard_bits(a) != guard_bits(b) or fact_bits(a) != fact_bits(b):
        return False
    for key in _TEXT_FIELDS:
        words, worst = word_deviation(body(a, key), body(b, key))
        if words > 1 or worst < 0.85:
            return False
    return True


def decision(s, op, at, reason, subject, changes=None):
    # 0.1.18: изменение правила записывается как «до/после», иначе историю нельзя восстановить (И-038).
    s['revision'] += 1
    item = {'revision': s['revision'], 'op': op, 'at': at, 'reason': string(reason, 'reason'),
            'subject': subject}
    if changes:
        item['changes'] = changes
    s['decisions'].append(item)


@dataclass
class Review:
    root: Path
    request: dict
    at: str
    seen: dict = field(default_factory=dict)
    after: dict = field(default_factory=dict)
    notes: list = field(default_factory=list)
    hints: list | None = None

    def observe(self, path, required=False):
        if path not in self.seen:
            self.seen[path] = read(self.root, path)
        value = self.seen[path]
        need(not required or value is not None, 'missing', 'Отсутствует необходимый файл.', {'path': path})
        return value

    def change(self, path, data):
        # 0.1.35: починка убирает свои же временные файлы в local/ — только удаление, не запись (И-055).
        need(path in TARGETS or (path.startswith(LOCAL) and data is None), 'boundary',
             'Запись не входит в закрытый список.')
        need(data is None or len(data) <= MAX_BYTES, 'limit', 'Результат слишком велик.')
        # 0.1.30: имя, совпадающее с существующим без учёта регистра, — тот же файл на NTFS (И-050, §16).
        conflicts = case_conflicts(self.root, [path])
        need(not conflicts, 'case', 'Имя совпадает с существующим без учёта регистра: на NTFS это один файл.',
             {'conflicts': conflicts})
        if data != self.observe(path):
            self.after[path] = data

    def fingerprint(self, extra=None):
        return digest(encode({'format': VERSION, 'root': str(self.root), 'at': self.at, 'request': self.request,
                              'before': {p: digest(b) for p, b in self.seen.items()},
                              'after': {p: digest(b) for p, b in self.after.items()}, 'entry_metadata': self.hints, 'extra': extra}))

    def describe(self, extra=None):
        items = []
        for path, data in self.after.items():
            old = self.seen[path]
            diff = ''.join(difflib.unified_diff((old or b'').decode('utf-8-sig').splitlines(True),
                        (data or b'').decode('utf-8-sig').splitlines(True), fromfile='до/'+path, tofile='после/'+path))
            items.append({'path': path, 'before': digest(old), 'after': digest(data), 'diff': diff})
        return {'ticket': {'at': self.at, 'digest': self.fingerprint(extra)}, 'changes': items, 'notes': self.notes,
                'request': self.request, 'writes': False,
                **({'same': self.same} if getattr(self, 'same', None) else {})}


def inspect_links(files):
    # Deliberately small grammar: inline relative Markdown links in shipped guides.
    # Targets are matched against the format, not followed on the filesystem.
    for name in ('START.md', 'PROTOCOL.md', 'entry.txt'):
        targets = []
        fenced = False
        for line in files[name].decode('utf-8').splitlines():
            if line.lstrip().startswith('```'):
                fenced = not fenced
            elif not fenced:
                targets.extend(re.findall(r'\[[^\]]*\]\(([^)]+)\)', line))
        allowed = {BASE + f for f in FILES} if name == 'entry.txt' else set(FILES) | {'../project/state.json', '../project/checks.json'}
        for dest in targets:
            need(dest.split('#', 1)[0] in allowed, 'link', 'Неизвестная цель внутренней ссылки.', {'file': name, 'target': dest})
        if name == 'entry.txt':
            need(BASE + 'START.md' in targets, 'link', 'Адаптер не ссылается на стартовый файл.')


def read_project(p, state=None, *, allow_drift=False, allow_conflict=False):
    s = parse(p.observe(STATE, True)) if state is None else state
    check_state(s)
    files = {n: p.observe(BASE + n, True) for n in FILES}
    m = manifest_check(files['manifest.json'])
    need(digest(files['manifest.json']) == s['base']['pin'] and m['base_version'] == s['base']['version'], 'trust', 'Установленный манифест не совпадает с одобренным.')
    drift = [n for n in DATA if digest(files[n]) != s['base']['installed'][n]]
    need(not drift or allow_drift, 'drift', 'Обнаружены несогласованные локальные изменения базы.', drift)
    base = base_check(files)
    inspect_links(files)
    recs = registry(base, s['entries'])
    issues = contradictions(recs)
    need(not issues or allow_conflict, 'conflict', 'Конфликт действующих правил.', issues)
    checks = check_results(p.observe(CHECKS, True))
    return s, files, m, recs, checks, drift, issues


def merge_base(old, local, new, choices):
    """3 inputs, never fall back to a guessed ancestor. Rules merged by ID.

    A divergent edit of one record, even on different fields, requires a choice.
    Missing records are distinct from present records. No conflict markers written.
    """
    need(type(choices) is dict and all(v in ('local', 'incoming') for v in choices.values()), 'resolutions', 'Разрешения: local или incoming.')
    used, unresolved = set(), []
    def one(key, a, b, c):
        if b == c or a == c:
            return b
        if a == b:
            return c
        if key in choices:
            used.add(key)
            return b if choices[key] == 'local' else c
        def printable(v):
            return v.decode('utf-8') if isinstance(v, bytes) else v
        unresolved.append({'key': key, 'original': printable(a), 'local': printable(b), 'incoming': printable(c)})
        return b
    out = {'manifest.json': new['manifest.json']}
    for n in DATA:
        if n == 'rules.json' and local[n] != old[n] and new[n] != old[n] and local[n] != new[n]:
            sets = [{e['id']: e for e in parse(b[n])['entries']} for b in (old, local, new)]
            merged = []
            for i in sorted(set.union(*(set(s) for s in sets))):
                record = one(n + ':' + i, *(s.get(i) for s in sets))
                if record is not None:
                    merged.append(record)
            out[n] = encode({'schema_version': 1, 'entries': merged})
        else:
            out[n] = one(n, old[n], local[n], new[n])
    need(not unresolved, 'merge_conflict', 'Нужен выбор по каждому конфликту.', unresolved)
    need(set(choices) == used, 'resolutions', 'Выбор относится к отсутствующему конфликту; перепроверьте план.')
    base_check(out)
    inspect_links(out)
    return out


def legacy_zero(s):
    """Supported interchange fixture, not a claim about a previously shipped product."""
    need(isinstance(s, dict) and type(s.get('schema_version')) is int and s['schema_version'] in (0, 1),
         'unknown_schema', 'Миграция этой версии схемы неизвестна: данные не переписаны, migrate не угадывает.',
         {'found': s.get('schema_version') if isinstance(s, dict) else None, 'supported': [0, 1],
          'migrate': False})
    exact(s, 'schema_version project_revision next_id entries decisions base adapter retired')
    need(s['schema_version'] == 0 and type(s['entries']) is list,
         'schema', 'Миграции подлежит только схема 0; текущая схема уже читается без неё.')
    s['schema_version'], s['revision'] = 1, s.pop('project_revision')
    for e in s['entries']:
        need(type(e) is dict and 'status' in e and 'state' not in e, 'migration', 'Неоднозначное преобразование status → state.')
        e['state'] = e.pop('status')
    check_state(s)
    return s


def plus_days(stamp, days):
    # 0.1.23: срок проверки считается от времени решения, а не от «сегодня» читателя (И-043, §10.3).
    moment = dt.datetime.strptime(stamp, '%Y-%m-%dT%H:%M:%SZ').replace(tzinfo=dt.timezone.utc)
    return (moment + dt.timedelta(days=days)).strftime('%Y-%m-%dT%H:%M:%SZ')


def mutate_entry(s, r, at):
    op = r['op']
    editable = 'title scope text basis criterion owner key value review_days'
    changes = []
    if op == 'create':
        exact(r, 'op kind title scope text basis criterion reason',
              'contract state key value owner review_days')
        i = 'P-' + str(s['next_id'])
        e = {k: r.get(k) for k in editable.split()}
        e.update(id=i, kind=r['kind'], contract=r.get('contract'), state=r.get('state', 'draft'), revision=1, updated_at=at, reason=string(r['reason']))
        need(e['state'] in ('draft', 'active'), 'transition', 'Новая запись должна быть draft или active.')
        # 0.1.21: секрет не попадает в реестр. В деталях — поле и вид образца, без значения (И-041, §9.5).
        for field in ('title', 'text', 'basis', 'criterion', 'key', 'value'):
            hits = secret_hits(e[field])
            need(not hits, 'secret', 'Похоже на секрет: значение не записывается и не печатается.',
                 {'field': field, 'kind': hits[0] if hits else None})
        # 0.1.27: состояние контракта проверяется на входе, а не объясняется потом через hidden (И-047, A-001).
        if e['contract'] is not None:
            parent = next((x for x in s['entries'] if x['id'] == e['contract']), None)
            need(parent is not None and parent['kind'] == 'contract', 'parent',
                 'Запись должна принадлежать существующему контракту.', {'contract': e['contract']})
            need(parent['state'] != 'revoked', 'parent',
                 'Контракт отменён: новые записи в нём не создаются.', {'contract': parent['id'],
                                                                       'state': parent['state']})
            if e['state'] == 'active':
                need(parent['state'] == 'active', 'state',
                     'Активная запись возможна только в действующем контракте.',
                     {'contract': parent['id'], 'parent_state': parent['state']})
        s['entries'].append(e)
        s['next_id'] += 1
    else:
        exact(r, {'edit': 'op id fields reason', 'transition': 'op id to reason',
                  'purge': 'op id reason allow_delete', 'review': 'op id reason'}[op],
              'allow_scope allow_owner actor' if op == 'edit'
              else 'review_days actor' if op == 'review' else 'actor')
        i = string(r['id'], 'id')
        e = next((x for x in s['entries'] if x['id'] == i), None)
        need(e is not None, 'id', 'Изменять можно только существующую проектную запись.', {'id': i})
        # 0.1.22: кто вправе менять правило. Владелец назван в записи, правка — от его имени (И-042, §10.1).
        owner = e.get('owner')
        if owner is not None:
            need(r.get('actor') == owner, 'not_owner', 'Менять правило вправе только его владелец.',
                 {'owner': owner, 'actor': r.get('actor')})
        new_owner = r['fields']['owner'] if op == 'edit' and 'owner' in r['fields'] else owner
        if op == 'edit' and new_owner != owner:
            need(r.get('allow_owner') is True, 'owner',
                 'Передача владения — отдельное согласие allow_owner.', {'from': owner, 'to': new_owner})
        if op == 'edit':
            exact(r['fields'], '', editable)
            need(e['state'] != 'revoked' and r['fields'], 'edit', 'Отменённая запись или пустое изменение.')
            for field, value in sorted(r['fields'].items()):
                hits = secret_hits(value)
                need(not hits, 'secret', 'Похоже на секрет: значение не записывается и не печатается.',
                     {'field': field, 'kind': hits[0] if hits else None})
            if all(e[k] == v for k, v in r['fields'].items()):
                # 0.1.23: повтор тем же значением — не правка. Ответ явный, версия не двигается (И-043, §10.2).
                return sorted(r['fields'])
            # 0.1.18: область — не текст. Её смена меняет охват действующего набора и требует согласия.
            if 'scope' in r['fields'] and r['fields']['scope'] != e['scope']:
                need(r.get('allow_scope') is True, 'scope',
                     'Смена области меняет охват правила. Нужно отдельное согласие allow_scope.',
                     {'from': e['scope'], 'to': r['fields']['scope']})
            changes = [{'field': k, 'before': e[k], 'after': v}
                       for k, v in r['fields'].items() if e[k] != v]
            e.update(r['fields'])
        elif op == 'transition':
            need(r['to'] in TRANSITIONS[e['state']], 'transition', 'Переход состояния не разрешён.', {'from': e['state'], 'to': r['to']})
            # 0.1.27: активная запись возможна только в действующем контракте — иначе обход через два шага (И-047, A-001).
            if r['to'] == 'active' and e['kind'] != 'contract':
                parent = next((x for x in s['entries'] if x['id'] == e['contract']), None)
                need(parent is not None and parent['state'] == 'active', 'state',
                     'Активная запись возможна только в действующем контракте.',
                     {'contract': e['contract'], 'parent_state': (parent or {}).get('state')})
            changes = [{'field': 'state', 'before': e['state'], 'after': r['to']}]
            e['state'] = r['to']
        elif op == 'review':
            # 0.1.23: когда проверять правило. Отметка проверки — решение, срок — данные записи (И-043, §10.3).
            need(e['state'] != 'revoked', 'review', 'Отменённую запись не проверяют.')
            days = r.get('review_days', e.get('review_days') or 90)
            need(integer(days, 1) and days <= 3650, 'review_days', 'Срок проверки — целое от 1 до 3650 дней.',
                 {'review_days': days})
            before = e.get('review_by')
            e.update(reviewed_at=at, review_days=days, review_by=plus_days(at, days))
            changes = [{'field': 'review_by', 'before': before, 'after': e['review_by']}]
        else:
            need(e['state'] == 'revoked' and r['allow_delete'] is True, 'delete', 'Удаление только после отмены и отдельного согласия.')
            need(not any(x['contract'] == i for x in s['entries']), 'parent', 'Есть дочерние записи. Каскадное удаление запрещено.')
            s['entries'].remove(e)
            # 0.1.20: удаление оставляет след. Содержимое не сохраняется, но запись о записи остаётся,
            # иначе по журналу нельзя ответить, что именно было удалено и когда (И-040, §9.4).
            s.setdefault('tombstones', []).append(
                {'id': i, 'kind': e['kind'], 'contract': e['contract'], 'scope': e['scope'],
                 'title': e['title'], 'at': at, 'reason': string(r['reason']), 'revision': e['revision']})
            changes = [{'field': 'entry', 'before': i, 'after': None}]
        if op == 'edit':
            # 0.1.23: версионируется содержимое правила, а не факт решения (И-043, §10.2).
            e['revision'] += 1
        e['updated_at'], e['reason'] = at, string(r['reason'])
    decision(s, op, at, r['reason'], i, changes)


def safe_target(lab, project):
    # 0.1.12: проект может лежать вне корня комплекта — тогда путь задаётся абсолютным (И-032, P1).
    # Относительный путь по-прежнему не выходит из лаборатории и не указывает на kit/releases.
    if project.startswith('/') or re.match(r'^[A-Za-z]:[\\/]', project):
        root = Path(project)
        need(root.is_dir(), 'root', 'Нужна существующая папка проекта.', {'path': project})
        lab_root = Path(lab).resolve()
        resolved = root.resolve()
        need(resolved != lab_root, 'root', 'Корень комплекта не может быть проектом.', {'path': project})
        for reserved in ('kit', 'releases'):
            need(resolved != lab_root / reserved and (lab_root / reserved) not in resolved.parents,
                 'root', 'Проект не может быть служебным каталогом комплекта.', {'path': project})
        need(not any(part.casefold() == '.agent-contract' for part in resolved.parts),
             'root', 'Проект не может быть служебным каталогом комплекта.', {'path': project})
        return resolved
    root = safe(lab, rel(project))
    need(root.is_dir() and project.split('/')[0].casefold() not in ('releases', 'kit') and
         all(part.casefold() != '.agent-contract' for part in project.split('/')),
         'root', 'Нужна отдельная существующая папка проекта, не kit/releases/служебный каталог.')
    return root


def install_space(root):
    # A failed/restored first installation leaves its own lock and journals.
    # It must be possible to retry without cleaning or adopting other files.
    folder = safe(root, '.agent-contract')
    if not folder.exists():
        return
    need(folder.is_dir(), 'occupied', 'Служебное имя занято файлом.')
    for item in folder.iterdir():
        need(item.name in ('base', 'project', 'local'), 'occupied', 'Неизвестный объект в служебном каталоге.')
        path = safe(root, PREFIX + item.name)
        need(path.is_dir(), 'occupied', 'Служебный каталог занят файлом.')
        if item.name == 'local':
            need(all(x.name in ('writer.lock','ops') for x in path.iterdir()), 'occupied', 'Неизвестные локальные данные.')
        else:
            need(not any(path.iterdir()), 'occupied', 'Не принимаем существующие данные под управление.')


def merge_checks(local_checks, incoming_checks):
    """0.1.13: объединение наблюдений двух машин по правилу тождества (И-033, решение Б по P4).

    Свои записи остаются на месте и в своём порядке. Из входящих добавляются только те, что ещё не
    известны: совпадение определяется тем же `same_observation`, что и при записи. Ничего не удаляется
    и не переписывается — объединение только добавляет.
    """
    merged = {'schema_version': 1, 'checks': [dict(item) for item in local_checks['checks']]}
    added, duplicates = 0, 0
    for item in incoming_checks['checks']:
        if any(same_observation(existing['observation'], item['observation']) for existing in merged['checks']):
            duplicates += 1
            continue
        merged['checks'].append(dict(item))
        added += 1
    return merged, added, duplicates


def plan(lab, project, r, at=None):
    root = safe_target(lab, project)
    p = Review(root, r, timestamp() if at is None else at)
    need(date_ok(p.at), 'time', 'Некорректное время билета.')
    need(type(r) is dict and type(r.get('op')) is str, 'request', 'Нужно указать op.')
    op = r['op']
    need(not pending(root), 'pending', 'Есть незавершённая операция. Сначала диагностика восстановления.')
    # 0.1.29: чужая запись в служебном каталоге — не повод продолжать (И-049, §11).
    guard_writes(root)
    if op == 'install':
        exact(r, 'op package pin')
        files, m = package(lab, r['package'], r['pin'])
        inspect_links(files)
        for path in TARGETS - {ENTRY}:
            need(p.observe(path) is None, 'occupied', 'Целевой файл уже существует.', {'path': path})
        # Unknown data in an existing control folder is never adopted or overwritten.
        install_space(root)
        for name, data in files.items():
            p.change(BASE + name, data)
        s = {'schema_version': 1, 'revision': 0, 'next_id': 1, 'entries': [], 'decisions': [],
             'base': baseline(m, files), 'adapter': None, 'retired': False}
        decision(s, op, p.at, 'Установлен отдельно одобренный выпуск.', m['base_version'])
        p.change(STATE, encode(s))
        p.change(CHECKS, encode({'schema_version': 1, 'checks': []}))
        p.notes.append('Профиль пуст. Нативный адаптер не подключён. Установленные расширения не проверялись.')
        return p
    elif op == 'merge':
        exact(r, 'op incoming')
        need(type(r['incoming']) is str, 'path', 'Нужен путь к входящему файлу проверок.')
        raw = read(root, rel(r['incoming']), required=True)
        incoming = check_results(raw)
        local = check_results(p.observe(CHECKS, True))
        merged, added, duplicates = merge_checks(local, incoming)
        p.notes.append({'added': added, 'duplicates': duplicates,
                        'identity': 'CONDITIONS', 'deleted': 0,
                        'incoming': r['incoming'], 'writes_foreign': False})
        if added:
            p.change(CHECKS, encode(merged))
        return p
    migrated = legacy_zero(parse(p.observe(STATE, True))) if op == 'migrate' else None
    s, local, lm, recs, checks, drift, issues = read_project(p, migrated, allow_drift=op=='update', allow_conflict=True)
    need(not s['retired'] or op in ('record_check',), 'retired', 'Контракт выведен из эксплуатации. Данные сохранены.')
    base = parse(local['rules.json'])['entries']
    if op in ('create', 'edit', 'transition', 'purge', 'review'):
        same = mutate_entry(s, r, p.at)
        if same:
            p.same = same
            p.notes.append('Значения совпадают с текущими: правки нет, версия не меняется (same: '
                           + ', '.join(same) + ').')

    elif op == 'migrate':
        exact(r, 'op reason')
        decision(s, op, p.at, r['reason'], '0 -> 1')
        p.notes.append('Только переименование project_revision → revision и status → state; неизвестные поля не удаляются.')
    elif op in ('connect', 'disconnect', 'retire'):
        exact(r, 'op', 'ack_existing entry_path' if op == 'connect' else 'allow_delete')
        adapter = s['adapter']
        if op == 'connect' and r.get('entry_path', ENTRY) != ENTRY:
            # Запрет на второй реестр как код отказа: комплект ведёт ровно один вход. Второй вход —
            # это два указателя, которые расходятся; вместо него — ручное чтение START.md или выбор
            # одной среды.
            raise Refusal('second_entry', 'Второй вход не создаётся: комплект ведёт ровно один вход. '
                          'Для сред, которые читают свой файл, доступно ручное чтение START.md.',
                          {'requested': r['entry_path'], 'entry': ENTRY})
        if op == 'connect':
            if adapter is not None:
                current = p.observe(ENTRY)
                need(digest(current) == adapter['sha256'] == digest(local['entry.txt']), 'adapter_drift', 'Принадлежащий контракту вход изменён или отсутствует.')
            else:
                need(not safe(root, ENTRY).exists(), 'foreign_entry', 'Вход уже занят. Он не будет принят под управление. Доступен ручной вход через START.md.')
                p.hints = native_hints(root)
                paths = [f['path'] for f in p.hints]
                need(r.get('ack_existing', []) == paths, 'existing_sources', 'Известны другие возможные источники инструкций. Присутствие не доказывает конфликт. Для совместного входа укажите перечисленные path в массиве ack_existing в данном порядке; иначе используйте ручное чтение.', p.hints)
                if paths:
                    p.notes.append({'existing_sources_not_read_or_modified': p.hints})
                p.change(ENTRY, local['entry.txt'])
                s['adapter'] = {'path': ENTRY, 'version': lm['adapter_version'], 'sha256': digest(local['entry.txt'])}
                decision(s, op, p.at, 'Создан вход; обнаружение и чтение не проверены.', ENTRY)
        else:
            if adapter is not None:
                need(r.get('allow_delete') is True, 'delete', 'Для удаления входа требуется явное allow_delete.')
                need(digest(p.observe(ENTRY)) == adapter['sha256'], 'adapter_drift', 'Чужую правку или отсутствующий вход не перезаписываем.')
                p.change(ENTRY, None)
                s['adapter'] = None
            if op == 'retire':
                s['retired'] = True
            if adapter is not None or op == 'retire':
                decision(s, op, p.at, 'Отключение без очистки пользовательских данных.', ENTRY)
    elif op == 'update':
        exact(r, 'op package pin', 'resolutions')
        try:
            old, om = package(lab, 'releases/' + s['base']['version'], s['base']['pin'])
        except (OSError, Refusal) as exc:
            raise Refusal('no_ancestor', 'Исходный одобренный выпуск недоступен. Трёхстороннее сравнение не выполнено.') from exc
        new, nm = package(lab, r['package'], r['pin'])
        def ver(m): return tuple(map(int, m['base_version'].split('.')))
        need(ver(nm) >= ver(om), 'downgrade', 'Автоматическое понижение запрещено.')
        need(ver(nm) != ver(om) or r['pin'] == s['base']['pin'], 'version_collision', 'Одна версия обозначает два разных выпуска.')
        merged = merge_base(old, local, new, r.get('resolutions', {}))
        base = parse(merged['rules.json'])['entries']
        for n in FILES:
            p.change(BASE+n, merged[n])
        binding = baseline(nm, merged)
        if s['adapter'] is not None:
            need(digest(p.observe(ENTRY)) == s['adapter']['sha256'], 'adapter_drift', 'Вход изменён вне контракта: остановка обновления.')
            p.change(ENTRY, merged['entry.txt'])
            s['adapter'].update(version=nm['adapter_version'], sha256=digest(merged['entry.txt']))
        if binding != s['base'] or p.after:
            s['base'] = binding
            decision(s, op, p.at, 'Сверены исходная, локальная и предлагаемая версии.', nm['base_version'])
        p.notes.extend(['Нет исполнения кода из выпуска. Повторить структурные проверки и новый сеанс каждого агента.',
                        {'unapproved_drift_before': drift, 'local_differences_after': [n for n in DATA if merged[n] != new[n]]}])
    elif op == 'record_check':
        exact(r, 'op observation')
        observation(r['observation'])
        match = next((n for n, c in enumerate(checks['checks'], 1)
                      if same_observation(c['observation'], r['observation'])), None)
        if match is not None:
            # Повтор не создаёт записи: одно и то же наблюдение можно записать другой формой слов.
            # Допуск ограничен измерением (см. PROTOCOL.md); всё, что дальше, — новая запись.
            p.notes.append(f'Наблюдение совпадает с уже записанным (запись {match}); новая запись не создаётся. '
                           'Наблюдатель (редактор, расширение, версии) не сравнивается.')
        else:
            checks['checks'].append({'at': p.at, 'revision': s['revision'], 'base_version': s['base']['version'],
                                     'adapter_version': (s['adapter'] or {}).get('version'), 'observation': r['observation']})
            p.change(CHECKS, encode(checks))
    elif op == 'calibrate_answer':
        # 0.1.35: ответ пишется до сравнения, а повтор допускается один раз и только по данным (И-055).
        exact(r, 'op prompt answer', 'allow_repeat')
        book = calibration_book(lab)
        prompt = next((item for item in book['prompts'] if item['id'] == r['prompt']), None)
        need(prompt is not None, 'prompt', 'Неизвестный промпт.', {'known': [p['id'] for p in book['prompts']]})
        stored = answers_book(root)
        previous = [rec for rec in stored['answers'] if rec['prompt'] == prompt['id']]
        if previous:
            last = previous[-1]['compare']
            need(r.get('allow_repeat') is True, 'repeat_answer',
                 'Ответ на этот промпт уже записан. Повтор — только явным согласием.', {'match': last['match']})
            need(last['match'] is False and last['reason'] == 'data', 'repeat_answer',
                 'Повтор предлагается, только если ответ не сошёлся по данным.', {'reason': last['reason']})
            need(len(previous) < 2, 'repeat_answer', 'Повтор допускается один раз.')
        compare = compare_answer(book, prompt, r['answer'], len(previous))
        stored['answers'].append({'at': p.at, 'prompt': prompt['id'], 'answer': r['answer'], 'compare': compare})
        p.change(CAL, encode(stored))
        p.notes.append({'written_first': True, 'match': compare['match'], 'reason': compare['reason'],
                        'next': compare['next'],
                        'note': 'Ответ записан в local/calibration/answers.json до сравнения: подогнать '
                                'постфактум нельзя, запись останется в журнале.'})
    elif op == 'fix':
        exact(r, 'op kind')
        changes = fix_plan(root, r['kind'])
        removed = []
        for path, data in changes.items():
            if data is None:
                # Свои временные файлы: удаление без журнала — в журнал попадает только содержимое контракта.
                (Path(root) / path).unlink()
                removed.append(path)
            else:
                p.change(path, data)
        p.notes.append({'kind': r['kind'], 'closed_list': list(FIX_KINDS), 'removed': removed,
                        'manual': 'всё, что не в списке, остаётся человеку: база и правила не меняются'})
    else:
        raise Refusal('op', 'Операция не поддерживается.')
    problems = contradictions(registry(base, s['entries']))
    need(not problems or op in ('record_check','retire','disconnect'), 'conflict',
         'Пересечение действующих требований. Нужен выбор владельца; молчаливого приоритета нет.', problems)
    check_state(s)
    # An unchanged state stays byte-identical (also if formatted by the owner).
    if s != parse(p.seen[STATE]):
        p.change(STATE, encode(s))
    return p


def journal_name(tx):
    need(type(tx) is str and TX.fullmatch(tx), 'transaction', 'Неверный ID операции.')
    return OPS + tx + '/plan.json'


def journal(root, tx):
    j = parse(read(root, journal_name(tx), required=True))
    exact(j, 'format tx root status ticket files op at')
    string(j['op'], 'op')
    need(date_ok(j['at']), 'journal', 'Неверное время операции.')
    need(type(j['format']) is int and j['format'] == 1 and j['tx'] == tx and j['root'] == str(root)
         and j['status'] in ('pending', 'committed', 'restored') and HEX.fullmatch(string(j['ticket'])), 'journal', 'Неподдерживаемый журнал.')
    need(type(j['files']) is dict and 0 < len(j['files']) <= len(TARGETS), 'journal', 'Неверный список файлов операции.')
    for path, h in j['files'].items():
        need(path in TARGETS, 'journal', 'Журнал указывает за пределы управляемых файлов.')
        exact(h, 'before after')
        need(h['before'] != h['after'] and all(x is None or (type(x) is str and HEX.fullmatch(x)) for x in h.values()), 'journal', 'Неверный отпечаток в журнале.')
    return j


def pending(root):
    folder = safe(root, OPS.rstrip('/'))
    if not folder.exists():
        return []
    result = []
    for d in sorted(folder.iterdir()):
        need(TX.fullmatch(d.name), 'journal', 'Неизвестный объект в каталоге журналов. Ничего не удалено.')
        marker = safe(root, journal_name(d.name))
        # A preparation without a published marker cannot have modified a destination.
        if not marker.exists():
            continue
        raw = parse(marker.read_bytes())
        # 0.1.12: журнал несёт абсолютный путь проекта. Приехавший из другого пути — это история
        # другой машины, а не незавершённая операция здесь (И-032, F8).
        if isinstance(raw, dict) and raw.get('root') != str(root):
            need(raw.get('status') in ('committed', 'restored'), 'journal_foreign',
                 'Незавершённая операция другой машины: здесь её нельзя продолжать.',
                 {'tx': d.name, 'root': raw.get('root')})
            continue
        if journal(root, d.name)['status'] == 'pending':
            result.append(d.name)
    return result


def confirm(ticket, p, extra=None):
    exact(ticket, 'at digest')
    need(ticket['at'] == p.at and ticket['digest'] == p.fingerprint(extra), 'stale_plan',
         'Билет не совпадает с точным планом. Получите новое сравнение; запись не выполнена.')


def unchanged(p):
    if p.hints is not None:
        need(native_hints(p.root) == p.hints, 'stale_plan', 'Изменились метаданные источников инструкций.')
    for path, value in p.seen.items():
        need(read(p.root, path) == value, 'stale_plan', 'Файл изменён после просмотра плана.', {'path': path})


def apply(lab, project, r, ticket, *, _after_write=None):
    exact(ticket, 'at digest')
    p = plan(lab, project, r, ticket['at'])
    confirm(ticket, p)
    if not p.after:
        return {'outcome': 'no_change', 'files': []}
    with writer(p.root):
        need(not pending(p.root), 'pending', 'Требуется восстановление.')
        unchanged(p)
        if r['op'] == 'install':
            # Lock creation itself introduces local/. Do not adopt a concurrently added control tree.
            install_space(p.root)
        tx = uuid.uuid4().hex
        j = {'format': 1, 'tx': tx, 'root': str(p.root), 'status': 'pending', 'ticket': ticket['digest'], 'files': {}, 'op': r['op'], 'at': p.at}
        for path, new in p.after.items():
            old = p.seen[path]
            if old is not None:
                backup = OPS + tx + '/before/' + path
                put(p.root, backup, old)
                need(read(p.root, backup, required=True) == old, 'backup', 'Не удалось подтвердить резервную копию.')
            j['files'][path] = {'before': digest(old), 'after': digest(new)}
        put(p.root, journal_name(tx), encode(j))  # durable intent before first managed write
        for idx, (path, new) in enumerate(p.after.items(), 1):
            need(read(p.root, path) == p.seen[path], 'stale_plan', 'Постороннее изменение; операция оставлена в журнале.', {'path': path})
            put(p.root, path, new)
            if _after_write is not None:  # in-process reliability tests only, never provided by a package/request
                _after_write(idx)
        need(all(read(p.root, path) == b for path, b in p.after.items()), 'postcondition', 'Не подтверждены конечные байты. Операция остаётся незавершённой.')
        j['status'] = 'committed'
        put(p.root, journal_name(tx), encode(j))
        return {'outcome': 'committed', 'transaction': tx, 'files': list(p.after)}


def recovery_plan(lab, project, r, at=None):
    exact(r, 'op tx', 'allow_delete')
    need(r['op'] in ('restore', 'undo'), 'op', 'Ожидается restore или undo.')
    root = safe_target(lab, project)
    p = Review(root, r, at if at is not None else timestamp())
    need(date_ok(p.at), 'time', 'Неверная дата.')
    tx = r['tx']
    j = journal(root, tx)
    need(j['status'] in (('committed', 'restored') if r['op']=='undo' else ('pending', 'restored')), 'journal', 'Для прерывания: restore; для явного отката завершённой операции: undo.')
    if r['op'] == 'undo':
        need(not pending(root), 'pending', 'Сначала завершите восстановление прерванной операции.')
    classes = {}
    if j['status'] == 'restored':
        return p, j, classes
    for path, h in j['files'].items():
        actual = digest(p.observe(path))
        classes[path] = 'before' if actual == h['before'] else 'after' if actual == h['after'] else 'foreign'
        if classes[path] == 'after':
            if h['before'] is None:
                if r.get('allow_delete') is not True:
                    classes[path] = 'delete_requires_consent'
                    continue
                old = None
            else:
                old = read(root, OPS + tx + '/before/' + path, required=True)
                need(digest(old) == h['before'], 'backup', 'Повреждена резервная копия. Запись запрещена.', {'path': path})
            p.change(path, old)
    if j['status'] == 'committed':
        need(all(v == 'after' for v in classes.values()), 'undo_guard', 'Откат завершённой операции требует точного постсостояния и согласия на каждое удаление.', classes)
    # 0.1.25: план восстановления называет, откуда взять прежнее содержимое неопознанного файла (И-045, §12.3).
    salvage = {path: OPS + tx + '/before/' + path for path, kind in classes.items()
               if kind == 'foreign' and j['files'][path]['before'] is not None}
    p.notes.append({'classification': classes, 'foreign_files_are_never_overwritten': True,
                    'salvage': salvage})
    return p, j, classes


def restore(lab, project, r, ticket):
    exact(ticket, 'at digest')
    p, j, classes = recovery_plan(lab, project, r, ticket['at'])
    confirm(ticket, p, j)
    if j['status'] == 'restored':
        return {'outcome': 'no_change', 'files': []}
    with writer(p.root):
        need(journal(p.root, r['tx']) == j, 'stale_plan', 'Журнал изменился.')
        unchanged(p)
        if j['status'] == 'committed':
            need(not pending(p.root), 'pending', 'Есть другая незавершённая операция.')
            j['status'] = 'pending'
            put(p.root, journal_name(r['tx']), encode(j))
        for path, data in p.after.items():
            need(read(p.root, path) == p.seen[path], 'stale_plan', 'Неожиданное изменение при восстановлении.')
            put(p.root, path, data)
        unresolved = [path for path, h in j['files'].items() if digest(read(p.root, path)) != h['before']]
        if not unresolved:
            j['status'] = 'restored'
            put(p.root, journal_name(r['tx']), encode(j))
        return {'outcome': 'partial' if unresolved else 'restored', 'files': list(p.after), 'unresolved': unresolved}


def publish_plan(lab, r, at=None):
    """Publish only an explicit allowlist from kit/base. No template scripts or hooks."""
    exact(r, 'op version origin adapter_version')
    need(r['op'] == 'publish' and SEV.fullmatch(string(r['version'], 'version', 32)) and integer(r['adapter_version'], 1), 'version', 'Неверные параметры публикации.')
    root = safe(lab, 'kit/base')
    data = {n: read(root, n, required=True) for n in DATA}
    base_check(data)
    inspect_links(data)
    m = {'format': 'agent-contract-release', 'schema_version': 1, 'base_version': r['version'],
         'adapter_version': r['adapter_version'], 'origin': string(r['origin'], 'origin'), 'files': {n: digest(b) for n,b in data.items()}}
    raw = encode(m)
    manifest_check(raw)
    dest = safe(lab, 'releases/' + r['version'])
    p = Review(dest, r, at if at is not None else timestamp())
    need(date_ok(p.at), 'time', 'Неверная дата билета.')
    need(not dest.exists(), 'occupied', 'Версия уже существует: не перезаписывается.')
    for n, b in {**data, 'manifest.json': raw}.items():
        p.seen[n], p.after[n] = None, b
    p.notes.append({'release_pin': digest(raw), 'transfer_list': list(FILES)})
    return p


def publish(lab, r, ticket):
    exact(ticket, 'at digest')
    p = publish_plan(lab, r, ticket['at'])
    confirm(ticket, p)
    parent = safe(lab, 'releases')
    mkdirs(parent)
    # Build out of sight of release discovery. No installed consumer is touched on a crash.
    staging = safe(lab, 'releases/.prepare-' + uuid.uuid4().hex)
    staging.mkdir()
    for name, data in p.after.items():
        put(staging, name, data)
        need(read(staging, name) == data, 'postcondition', 'Не подтверждены байты выпуска.')
    # Concurrent publishers of this kit never overwrite an existing release.
    with writer(parent, '.publish.lock'):
        need(not fscheck(p.root).exists(), 'occupied', 'Версия уже опубликована.')
        os.rename(staging, p.root)
        flushdir(parent)
    return {'outcome': 'published', 'package': 'releases/' + r['version'], 'pin': digest(p.after['manifest.json'])}


def available(lab):
    root = safe(lab, 'releases')
    releases = []
    if root.is_dir():
        def _order(folder):
            # 0.1.9: порядок по версии, а не по строке: иначе 0.1.10 встаёт перед 0.1.9.
            return tuple(map(int, folder.name.split('.'))) if SEV.fullmatch(folder.name) else (0,)
        for d in sorted(root.iterdir(), key=_order):
            if SEV.fullmatch(d.name):
                raw = read(root, d.name + '/manifest.json', required=True)
                m = manifest_check(raw)
                need(m['base_version'] == d.name, 'version', 'Версия не совпадает с именем каталога.')
                releases.append({'folder': 'releases/' + d.name, 'version': m['base_version'], 'observed_hash': digest(raw), 'trust_verified': False})
    return releases


SECRET_PATTERNS = (
    ('github_token', re.compile(r'gh[pousr]_[A-Za-z0-9]{20,}')),
    ('github_fine_pat', re.compile(r'github_pat_[A-Za-z0-9_]{20,}')),
    ('aws_key', re.compile(r'AKIA[0-9A-Z]{16}')),
    ('openai_key', re.compile(r'sk-[A-Za-z0-9]{20,}')),
    ('slack_token', re.compile(r'xox[baprs]-[A-Za-z0-9-]{10,}')),
    ('google_key', re.compile(r'AIza[0-9A-Za-z_\-]{35}')),
    ('private_key', re.compile(r'-----BEGIN [A-Z ]*PRIVATE KEY-----')),
    ('jwt', re.compile(r'eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}')),
    ('assignment', re.compile(r'(?i)\b(?:password|passwd|secret|token|api[_-]?key)\s*[:=]\s*\S{6,}')),
)
SECRET_HIDDEN = '[скрыто]'


def secret_hits(text):
    """0.1.21: что похоже на секрет — по виду, а не по значению (И-041, §9.5)."""
    if type(text) is not str:
        return []
    return [kind for kind, pattern in SECRET_PATTERNS if pattern.search(text)]


def redact(value):
    """Найденный секрет заменяется меткой; возвращается ещё и число замен."""
    total = 0
    for _kind, pattern in SECRET_PATTERNS:
        value, n = pattern.subn(SECRET_HIDDEN, value)
        total += n
    return value, total


def scrub(node):
    """Очистка ответа целиком: секрет не печатается, даже если уже лежит в старом реестре."""
    if type(node) is str:
        return redact(node)
    if type(node) is list:
        out, total = [], 0
        for item in node:
            clean, n = scrub(item)
            out.append(clean)
            total += n
        return out, total
    if type(node) is dict:
        out, total = {}, 0
        for key, item in node.items():
            clean, n = scrub(item)
            out[key] = clean
            total += n
        return out, total
    return node, 0


def scrubbed(answer):
    clean, found = scrub(answer)
    if found and type(clean) is dict:
        clean['redacted'] = found
    return clean


def scene_set(items):
    """0.1.28: сценарий — действующий набор, сведённый к фактам (И-048, §15)."""
    facts = {}
    for e in items:
        key = e.get('key')
        ident = ('key', key, e['scope']) if key else ('text', (e.get('text') or ''), e['scope'])
        facts.setdefault(ident, []).append({'id': e['id'], 'title': e['title'], 'scope': e['scope'],
                                            'key': key, 'value': e.get('value'),
                                            'bytes': len((e.get('text') or '').encode('utf-8'))})
    return facts


def scene_compare(here, there):
    """Сравнение двух наборов: same, changed по значению, только здесь и только там (И-048)."""
    same, changed, only_here, only_there = [], [], [], []
    for ident, rows in here.items():
        other = there.get(ident)
        if other is None:
            only_here.extend(rows)
            continue
        values = {r['value'] for r in rows} | {r['value'] for r in other}
        if ident[0] == 'key' and len(values) > 1:
            changed.append({'key': ident[1], 'scope': ident[2], 'here': [r['id'] for r in rows],
                            'there': [r['id'] for r in other],
                            'values_here': sorted({r['value'] for r in rows}, key=str),
                            'values_there': sorted({r['value'] for r in other}, key=str)})
        else:
            same.extend(rows)
    for ident, rows in there.items():
        if ident not in here:
            only_there.extend(rows)
    return {'same': same, 'changed': changed, 'only_here': only_here, 'only_there': only_there}


def dispatch(lab, project, command, payload, target=None):
    """0.1.21: любой ответ проходит очистку — секрет не печатается (И-041, §9.5)."""
    return scrubbed(serve(lab, project, command, payload, target))


def serve(lab, project, command, payload, target=None):
    if command == 'updates':
        exact(payload, '')
        releases = available(lab)
        installed = None
        if project != '.':
            root = safe_target(lab, project)
            need(not pending(root), 'pending', 'Не определяем версию по частично обновлённому проекту.')
            raw = read(root, STATE)
            if raw is not None:
                state = parse(raw)
                check_state(state)
                installed = state['base']['version']
        for candidate in releases:
            candidate['newer'] = tuple(map(int,candidate['version'].split('.'))) > tuple(map(int,installed.split('.'))) if installed else None
        return {'installed_version': installed, 'local_candidates': releases, 'network': False}
    if command in ('plan', 'apply'):
        if command == 'apply':
            exact(payload, 'request ticket')
            r, ticket = payload['request'], payload['ticket']
        else:
            r, ticket = payload, None
        need(isinstance(r, dict), 'request', 'Нужен объект запроса.')
        if r.get('op') == 'publish':
            return publish_plan(lab, r).describe() if command == 'plan' else publish(lab, r, ticket)
        if r.get('op') in ('restore', 'undo'):
            if command == 'apply':
                return restore(lab, project, r, ticket)
            p, j, _ = recovery_plan(lab, project, r)
            return p.describe(j)
        return plan(lab, project, r).describe() if command == 'plan' else apply(lab, project, r, ticket)
    root = safe_target(lab, project)
    if command == 'session':
        # 0.1.19: разовый запрос — не правило. Он не сохраняется, и попытка сохранить его отклоняется
        # своим кодом, а не молчаливым согласием (И-039, §9.3).
        exact(payload, 'kind text', 'scope persist save')
        need(payload['kind'] in ('temporary', 'proposal', 'hypothesis'), 'not_a_request',
             'Это не разовый запрос: правило создаётся отдельной операцией create, с причиной и ревизией.',
             {'kind': payload['kind'], 'allowed': ['temporary', 'proposal', 'hypothesis'],
              'as_rule': {'op': 'create', 'kind': 'rule', 'reason': '…'}})
        if payload.get('persist') is True or payload.get('save') is True:
            raise Refusal('not_saved',
                          'Разовый запрос не сохраняется: у него нет ревизии, истории и области действия. '
                          'Чтобы правило действовало на будущее, оформите его операцией create.',
                          {'as_rule': {'op': 'create', 'kind': 'rule', 'scope': payload.get('scope', '.'),
                                       'text': payload.get('text'), 'reason': '…'}})
        text = string(payload['text'], 'text', 4000)
        # 0.1.21: разовый запрос не несёт секрет — он всё равно уходит в среду и в отчёт (И-041).
        hits = secret_hits(text)
        need(not hits, 'secret',
             'Похоже на секрет: такое значение не передаётся через комплект.',
             {'field': 'text', 'kind': hits[0] if hits else None})
        scope = payload.get('scope', '.')
        rel(scope, dot=True)
        before = tree_digest(root)
        answer = {'kind': payload['kind'], 'persisted': False, 'stored': False, 'writes': False,
                  'active_rule_created': False, 'rule_created': False, 'applies': 'этот запуск',
                  'scope': scope, 'text_bytes': len(text.encode('utf-8')),
                  'as_rule': {'op': 'create', 'kind': 'rule', 'scope': scope, 'reason': '…'},
                  'note': 'Разовый запрос исполняется в этом запуске и не попадает в реестр: у него нет '
                          'ревизии, истории и области действия. Правило — отдельное решение create.'}
        answer['project_unchanged'] = tree_digest(root) == before
        return answer
    if command == 'discovery':
        # 0.1.15: обнаружение названо данными, но не выдаётся за проверку (И-035, уровень 2).
        exact(payload, 'environment')
        return discovery(root, payload['environment'])
    if command == 'adapter':
        exact(payload, 'name')
        need(payload['name'] in ADAPTERS, 'adapter_unknown', 'Неизвестная среда: карточка не выдаётся.',
             sorted(ADAPTERS))
        card = dict(ADAPTERS[payload['name']])
        if 'priority' in card:
            card['priority'] = dict(card['priority'])
        known = set(card['sources'])
        card['present'] = [h for h in native_hints(root) if h['path'] in known]
        card['writes'] = False
        card['contents_read'] = False
        card['discovery_proven'] = False
        return card
    if command == 'entry':
        # 0.1.16: уровень 3 — что именно прочитает среда и опознан ли это наш вход (И-036).
        exact(payload, 'environment')
        need(not pending(root), 'pending', 'Сначала диагностика незавершённого изменения.')
        review = Review(root, {}, timestamp())
        s, files, _m, _r, _c, _d, _i = read_project(review, None, allow_drift=True,
                                                    allow_conflict=True)
        name = payload['environment']
        map_ = discovery(root, name)
        path = map_['chosen']
        line = files['entry.txt'].decode('utf-8').strip()
        levels = {'1_file_present': 'pass' if path else 'fail', '2_environment_found': 'not run',
                  '3_content_read_by_contract': 'not run', '3_content_read_by_model': 'not run',
                  '5_behavior_repeatable': 'not run'}
        if path is None:
            levels['1_file_present'] = 'fail'
            return {'environment': name, 'path': None, 'owned': False, 'foreign': False, 'read': None,
                    'levels': levels, 'content_proven': False, 'writes': False,
                    'note': 'Входа нет: читать нечего.'}
        owned = s['adapter'] is not None and path == ENTRY
        if not owned:
            levels['3_content_read_by_contract'] = 'not run'
            return {'environment': name, 'path': path, 'owned': False, 'foreign': True, 'read': None,
                    'bytes': safe(root, path).lstat().st_size, 'content': 'not read (foreign)',
                    'levels': levels, 'content_proven': False, 'writes': False,
                    'note': 'Это не вход комплекта: содержимое не читалось и не будет. Второй реестр '
                            'не создаётся, чужой файл не перезаписывается.'}
        raw = read(root, path, required=True)
        text = raw.decode('utf-8')
        levels['3_content_read_by_contract'] = 'pass'
        return {'environment': name, 'path': path, 'owned': True, 'foreign': False,
                'read': {'path': path, 'bytes': len(raw), 'sha256': digest(raw),
                         'lines': text.count('\n') + (0 if text.endswith('\n') else 1)},
                'marker_found': line in text, 'points_to': '.agent-contract/base/START.md' if line in text else None,
                'preview': text[:200],
                'levels': levels, 'content_proven': False, 'writes': False,
                'note': 'Содержимое прочитал комплект, а не модель: уровень 3 в смысле «модель прочитала» '
                        'остаётся not run.'}
    if command == 'calibrate':
        # 0.1.35: промпт с известным ответом; значения эталона в поставке отсутствуют (И-055).
        book = calibration_book(lab)
        stored = answers_book(root)
        by_prompt = {}
        for record in stored['answers']:
            by_prompt[record['prompt']] = by_prompt.get(record['prompt'], []) + [record]
        if payload.get('report') is True:
            rows = []
            for prompt in book['prompts']:
                records = by_prompt.get(prompt['id'], [])
                rows.append({'prompt': prompt['id'], 'answered': bool(records),
                             'attempts': len(records),
                             'match': records[-1]['compare']['match'] if records else None,
                             'reason': records[-1]['compare']['reason'] if records else None,
                             'next': records[-1]['compare']['next'] if records else 'answer'})
            return {'report': rows, 'answered': sum(1 for r in rows if r['answered']),
                    'matched': sum(1 for r in rows if r['match'] is True),
                    'remaining_manual': sorted({m for record in stored['answers']
                                                for m in record['compare'].get('manual') or []}),
                    'fixes': list(FIX_KINDS),
                    'reference': 'прозаические эталоны — в отдельном архиве AgentContractKit-Calibration; '
                                 'в поставке только отпечатки, восстановить значение по ним нельзя',
                    'writes': False}
        if 'prompt' not in payload:
            exact(payload, '', 'prompt report')
            return {'prompts': [{'id': p['id'], 'title': p['title'], 'steps': len(p.get('steps') or []),
                                 'facts': [item['key'] for item in p['facts']],
                                 'answered': p['id'] in by_prompt} for p in book['prompts']],
                    'schema_version': book['schema_version'], 'system_version': book['system_version'],
                    'format': 'prompt system_version schema_version environment facts not_run manual verdict_self',
                    'note': 'Эталон хранится отпечатками: сводятся только ваши значения, не наоборот.',
                    'writes': False}
        exact(payload, 'prompt', 'prompt answer')
        prompt = next((p for p in book['prompts'] if p['id'] == payload['prompt']), None)
        need(prompt is not None, 'prompt', 'Неизвестный промпт.', {'known': [p['id'] for p in book['prompts']]})
        if 'answer' not in payload:
            return {'prompt': prompt['id'], 'title': prompt['title'], 'steps': prompt.get('steps') or [],
                    'facts': [{'key': item['key'], 'digest': item['digest']} for item in prompt['facts']],
                    'environment_expected': prompt.get('environment') or {},
                    'expect_not_run': prompt.get('not_run') or [], 'expect_manual': prompt.get('manual') or [],
                    'how': 'запустите шаги, соберите ответ в формате выше и запишите его через plan/apply '
                           'с op calibrate_answer; только после записи compare назовёт совпадение',
                    'writes': False}
        attempts = len(by_prompt.get(prompt['id'], []))
        return compare_answer(book, prompt, payload['answer'], attempts)

    if command == 'repeat':
        # 0.1.17: уровень 5 — серия чтений, а не одно чтение (И-037).
        exact(payload, 'runs requests')
        return repeat_reads(lab, project, root, payload['runs'], payload['requests'])
    # 0.1.28: у metrics есть параметр чтения against — сравнение с другим сценарием (И-048).
    # 0.1.31: у verify своя форма — ответ модели (И-051, §14 ур. 4).
    if command == 'verify':
        need(isinstance(payload, dict), 'format', 'Ожидается объект JSON.')
    else:
        exact(payload, '', 'against' if command == 'metrics' else '')
    if command == 'inventory':
        return {'native_paths': native_hints(root), 'entry_exists': safe(root, ENTRY).exists(), 'contents_read': False, 'runtime_inferred': False}
    outstanding = pending(root)
    if command == 'operations':
        folder = safe(root, OPS.rstrip('/'))
        records = [journal(root, d.name) for d in sorted(folder.iterdir()) if safe(root, journal_name(d.name)).exists()] if folder.is_dir() else []
        return {'operations': [{k: j[k] for k in ('tx','at','op','status')} for j in records]}
    if command == 'pending':
        return {'pending': outstanding}
    if outstanding and command == 'status':
        # 0.1.25: частичный сбой виден до восстановления и называет, что осталось и чем спасать (И-045, §12.3).
        detail = []
        for tx in outstanding:
            try:
                j = journal(root, tx)
            except Refusal:
                detail.append({'tx': tx, 'op': None, 'files': {}, 'salvage': {}, 'next': 'restore'})
                continue
            files, salvage = {}, {}
            for path, h in j['files'].items():
                actual = digest(read(root, path))
                files[path] = 'before' if actual == h['before'] else 'after' if actual == h['after'] else 'foreign'
                if files[path] == 'foreign' and h['before'] is not None:
                    copy = OPS + tx + '/before/' + path
                    salvage[path] = {'copy': copy, 'intact': digest(read(root, copy)) == h['before']}
            detail.append({'tx': tx, 'op': j['op'], 'files': files, 'salvage': salvage,
                           'foreign_files_are_never_overwritten': True, 'next': 'restore'})
        return {'health': 'partial', 'pending': outstanding, 'pending_detail': detail, 'writes': False}
    need(not outstanding, 'pending', 'Сначала диагностика незавершённого изменения.')
    if command == 'access':
        # 0.1.33: право — это факт, а не обещание: измеряем записью в каталоге самого пути (И-053, §4 п. 8–9).
        exact(payload, '')
        paths = {}
        left = []
        for path in sorted(TARGETS):
            folder = (Path(root) / path).parent
            pending_dir = None
            probe_dir = folder
            while not probe_dir.is_dir() and probe_dir != probe_dir.parent:
                pending_dir = probe_dir
                probe_dir = probe_dir.parent
            if not probe_dir.is_dir():
                paths[path] = {'writable': False, 'reason': 'no_directory', 'errno': None, 'dir': None}
                continue
            # 0.1.35: каталога может ещё не быть — тогда мерим ближайший существующий и говорим об этом (И-055).
            extra = {'dir': None if pending_dir is None else pending_dir.relative_to(root).as_posix() + '/'}
            probe = probe_dir / ('.agent-contract-probe-' + uuid.uuid4().hex[:12])
            try:
                with open(probe, 'w', encoding='utf-8') as handle:
                    handle.write('probe\n')
                    handle.flush()
                    os.fsync(handle.fileno())
            except OSError as exc:
                reason = 'permission' if exc.errno in (errno.EACCES, errno.EPERM, errno.EROFS) else 'io'
                paths[path] = dict({'writable': False, 'reason': reason, 'errno': exc.errno}, **extra)
            else:
                paths[path] = dict({'writable': True, 'reason': None, 'errno': None}, **extra)
            finally:
                with contextlib.suppress(OSError):
                    probe.unlink()
            if probe.exists():
                left.append(probe.relative_to(root).as_posix())
        return {'paths': paths, 'measured': True, 'writes': False, 'left': left,
                'all_writable': all(item['writable'] for item in paths.values()),
                'probe': 'в каталоге самого пути: файл .agent-contract-probe-… создаётся, проверяется и удаляется '
                         'в той же операции; данные проекта не читаются и не меняются',
                'note': 'Права ОС комплект не выдаёт; он их измеряет. Ответ — факт на момент вызова, а не обещание: '
                        'право может измениться сразу после него.'}
    if command == 'layout':
        # 0.1.32: где лаборатория относительно проекта — раскладка названа, а не подразумевается (И-052).
        exact(payload, '')
        proj = Path(root).resolve()
        kit_root = Path(lab).resolve()

        def inside(child, parent):
            return child != parent and parent in child.parents

        if inside(kit_root, proj):
            relation = 'lab_inside_project'
        elif inside(proj, kit_root):
            relation = 'project_inside_lab'
        elif proj.parent == kit_root.parent:
            relation = 'siblings'
        else:
            relation = 'elsewhere'
        relative = kit_root.relative_to(proj).as_posix() if relation == 'lab_inside_project' else None
        notes = {
            'lab_inside_project': 'Архив распакован в корень проекта: проект — сам корень, лаборатория — '
                                  'каталог внутри него. Комплект пишет только в .agent-contract/ и AGENTS.md; '
                                  'файлы лаборатории (kit/, releases/, reports/) остаются как есть и контрактом '
                                  'не управляются. При переносе проекта лабораторию переносят вместе с ним.',
            'project_inside_lab': 'Проект лежит внутри лаборатории: обновление и восстановление берут архивы '
                                  'из releases/ лаборатории. Чтобы перенести проект отдельно, скопируйте '
                                  'лабораторию и проект вместе — иначе обновлять будет нечем.',
            'siblings': 'Лаборатория и проект — соседние каталоги: проект переносим отдельно, лаборатория '
                        'остаётся общей для нескольких проектов.',
            'elsewhere': 'Лаборатория вне проекта: пути не связаны. Проект переносится отдельно; проверьте, '
                         'что лаборатория остаётся доступной при переносе.',
        }
        warnings = []
        if relation == 'lab_inside_project':
            warnings.append('лаборатория внутри проекта: каталог ' + str(relative) +
                            '/ может попасть в систему контроля версий — исключите его, если не нужен в репозитории')
        return {'project': proj.as_posix(), 'lab': kit_root.as_posix(), 'relation': relation,
                'lab_relative': relative, 'contract': PREFIX.rstrip('/'), 'entry': ENTRY,
                'installed': (proj / STATE).is_file(), 'supported': True,
                'note': notes[relation], 'warnings': warnings,
                'how': ['распакуйте архив в корень проекта', 'проверьте раскладку этой командой',
                        'дальше — порядок первого обращения в START.md'],
                'writes': False}
    p = Review(root, {}, timestamp())
    if p.observe(STATE) is None and command == 'status':
        exists = safe(root, '.agent-contract').exists()
        return {'health': 'uninitialized_or_residual' if exists else 'absent', 'writes': False}
    s, files, m, recs, checks, drift, issues = read_project(p, allow_drift=True, allow_conflict=True)
    if command == 'identity':
        # 0.1.13: правило единства события названо данными, а не только абзацем в справочнике.
        exact(payload, '')
        return {'decision': 'Б', 'iteration': 'И-033',
                'compared': list(CONDITIONS), 'ignored': list(OBSERVER),
                'meaning': 'Событие — то, что видел такой-то участник: платформа, режим, модель и права '
                           'входят в тождество, редактор и расширение — происхождение записи.',
                'observer_out_since': '0.1.9', 'identity_since': '0.1.9',
                'declared_not_measured': True, 'writes': False}
    if command == 'brief':
        # 0.1.12: ручной вход для проекта, где AGENTS.md уже занят (И-032, P2). Комплект ничего не
        # пишет в чужой файл: он отдаёт ровно ту строку, которую владелец вписывает сам, и путь к
        # каноническому источнику. Второй реестр не создаётся: строка только указывает на START.md.
        owned = s['adapter'] is not None
        exists = safe(root, ENTRY).exists()
        return {'entry': ENTRY, 'mode': 'owned' if owned else 'foreign' if exists else 'absent',
                'writes': False, 'start': '.agent-contract/base/START.md',
                'line': files['entry.txt'].decode('utf-8').strip(),
                'how': 'Впишите эту строку в свой AGENTS.md вручную. Комплект чужой файл не '
                       'перезаписывает: содержимое не читалось, второй реестр не создаётся.',
                'start_sha256': digest(files['START.md']), 'entry_sha256': digest(files['entry.txt']),
                'discovery_proven': False}
    if command == 'status':
        adapter = s['adapter']
        # Never read the contents of an unowned instruction file for automatic attachment.
        exists = safe(root, ENTRY).exists()
        entry = ('absent' if not exists else 'unmanaged') if adapter is None else (
            'created' if digest(read(root, ENTRY)) == adapter['sha256'] else 'drift')
        # 0.1.12: режим входа назван прямо. Чужой файл не присваивается, но и не блокирует работу.
        entry_mode = 'owned' if entry == 'created' else 'foreign' if entry == 'unmanaged' else entry
        return {'health': 'attention' if drift or issues or entry == 'drift' else 'retired' if s['retired'] else 'valid',
                'schema_version': 1, 'project_revision': s['revision'], 'base': s['base'], 'entry': entry,
                'entry_mode': entry_mode, 'brief_available': not exists or entry == 'created',
                'adapter_version': (adapter or {}).get('version'), 'unapproved_drift': drift,
                'base_local_edits': [n for n in DATA if digest(files[n]) != m['files'][n]], 'conflicts': issues,
                'foreign': foreign_files(root),
                'observations': checks['checks'], 'removed': len(s.get('tombstones', [])),
                'runtime_inferred': False}
    if command == 'due':
        # 0.1.23: когда проверять правило. Ответ — данные записи, чтение ничего не пишет (И-043, §10.3).
        exact(payload, '')
        at = timestamp()
        due = []
        for e in s['entries']:
            if e['kind'] != 'rule' or e['state'] == 'revoked':
                continue
            by = e.get('review_by')
            if by is None:
                due.append({'id': e['id'], 'title': e['title'], 'scope': e['scope'], 'owner': e.get('owner'),
                            'state': e['state'], 'review_by': None, 'never': True, 'overdue': False})
            elif by <= at:
                due.append({'id': e['id'], 'title': e['title'], 'scope': e['scope'], 'owner': e.get('owner'),
                            'state': e['state'], 'review_by': by, 'never': False, 'overdue': True})
        return {'due': sorted(due, key=lambda x: x['id']), 'count': len(due), 'checked_at': at,
                'writes': False,
                'note': 'Правила без срока проверки или с истёкшим сроком. Отметить проверку — операция review.'}
    if command == 'metrics':
        # 0.1.26: стоимость и шум считаются по машине состояний, а не по числу строк реестра (И-046, §15).
        # 0.1.28: против второго сценария — сравнение действующего набора (И-048, §15).
        exact(payload, '', 'against')
        at = timestamp()
        active = [] if s['retired'] else effective(recs, target)
        active_ids = set(e['id'] for e in active)
        def slice_of(items):
            return {'count': len(items),
                    'bytes': sum(len((e.get('text') or '').encode('utf-8')) for e in items)}
        by_state, by_kind = {}, {}
        for e in s['entries']:
            by_state[e['state']] = by_state.get(e['state'], 0) + 1
            by_kind[e['kind']] = by_kind.get(e['kind'], 0) + 1
        noise = [e for e in s['entries'] if e['kind'] != 'contract' and e['state'] in ('draft', 'suspended')]
        # 0.1.27: скрытое — это состояние контракта, а не сужение по target (И-047, A-001, A8).
        hidden = [] if s['retired'] else [e for e in s['entries'] if e['kind'] != 'contract'
                                          and e['state'] == 'active'
                                          and recs[e['contract']]['state'] != 'active']
        if s['retired']:
            hidden = [e for e in s['entries'] if e['kind'] != 'contract' and e['state'] == 'active']
        reasons = {'parent_draft': 0, 'parent_suspended': 0, 'parent_revoked': 0, 'retired': 0}
        for e in hidden:
            if s['retired']:
                reasons['retired'] += 1
            else:
                reasons['parent_' + recs[e['contract']]['state']] += 1
        revoked = [e for e in s['entries'] if e['state'] == 'revoked']
        transitions = [d for d in s['decisions'] if d['op'] == 'transition']
        moves = {}
        for d in transitions:
            for c in d.get('changes', []):
                if c['field'] == 'state':
                    key = (c['before'] or '?') + '→' + (c['after'] or '?')
                    moves[key] = moves.get(key, 0) + 1
        rules = [e for e in s['entries'] if e['kind'] == 'rule' and e['state'] != 'revoked']
        never = len([e for e in rules if e.get('review_by') is None])
        overdue = len([e for e in rules if e.get('review_by') is not None and e['review_by'] <= at])
        answer = {'writes': False, 'target': target, 'checked_at': at,
                'entries': {'total': len(s['entries']), 'by_state': by_state, 'by_kind': by_kind},
                'active': slice_of(active),
                'noise': dict(slice_of(noise), states=['draft', 'suspended'],
                              why='реестр помнит, набор не применяет'),
                'hidden': dict(slice_of(hidden), ids=[e['id'] for e in hidden], by_reason=reasons,
                               why='правило active, но контракт не active или проект retired'),
                'revoked': slice_of(revoked),
                'transitions': {'count': len(transitions), 'by': moves},
                'review': {'never': never, 'overdue': overdue, 'checked_at': at},
                'meaning': {'bytes': 'длина текста в UTF-8 — стоимость чтения участником',
                            'active': 'active-правило под active-контрактом, в пределах target',
                            'noise': 'draft и suspended: место в реестре без действия',
                            'hidden': 'active-правило, отсечённое состоянием контракта',
                            'transitions': 'переходы состояний из истории решений'}}
        against = payload.get('against')
        if against is not None:
            need(isinstance(against, str) and against.strip(), 'against',
                 'Нужен путь ко второму сценарию.', {'against': against})
            try:
                other_root = safe_target(lab, against)
                other_state, _, _, other_recs, _, _, _ = read_project(Review(other_root, {}, at))
            except Refusal as e:
                raise Refusal('compare', 'Второй сценарий не читается как действующий набор.',
                              {'against': against, 'reason': e.code, 'details': e.details})
            there = [] if other_state['retired'] else effective(other_recs, target)
            diff = scene_compare(scene_set(active), scene_set(there))
            here_bytes = sum(len((e.get('text') or '').encode('utf-8')) for e in active)
            there_bytes = sum(len((e.get('text') or '').encode('utf-8')) for e in there)
            answer['compare'] = {
                'against': str(other_root),
                'here': dict(slice_of(active), ids=[e['id'] for e in active]),
                'there': dict(slice_of(there), ids=[e['id'] for e in there]),
                'cost': {'bytes_here': here_bytes, 'bytes_there': there_bytes,
                         'delta': here_bytes - there_bytes},
                'active': {'same': [r['id'] for r in diff['same']],
                           'changed': diff['changed'],
                           'only_here': diff['only_here'],
                           'only_there': diff['only_there']},
                'noise': {'here': len(noise),
                          'there': len([e for e in other_state['entries']
                                        if e['kind'] != 'contract' and e['state'] in ('draft', 'suspended')])},
                'note': 'Сравнивается действующий набор обоих сценариев: draft, suspended, hidden и revoked '
                        'в сравнение не входят. Правило опознаётся key+scope (иначе текстом) — id у сценариев свой.'}
        return answer
    if command == 'system':
        # 0.1.30: чужая файловая система — что измерено, а что объявлено (И-050, §16).
        exact(payload, '')
        entry = root / ENTRY
        probe = None
        if entry.is_file():
            alt = entry.with_name(entry.name.swapcase())
            probe = {'name': entry.name, 'other_case': alt.name,
                     'same_file': alt.name != entry.name and alt.exists()}
        return {'os': os.name, 'sep': os.sep,
                'case_insensitive': None if probe is None else probe['same_file'],
                'probe': probe,
                'declared': {'max_path': 260 if os.name == 'nt' else 4096,
                             'name_bytes': 255,
                             'reserved': ['CON', 'PRN', 'AUX', 'NUL', 'COM1…COM9', 'LPT1…LPT9'],
                             'forbidden': '\\ : " < > | ? * и управляющие символы',
                             'unicode': 'NFC'},
                'proven': {'case_insensitive': probe is not None,
                           'max_path': False, 'name_bytes': False, 'unicode': False},
                'writes': False,
                'note': 'Регистр измерен чтением соседнего имени, без записи. Лимиты и форма юникода '
                        'объявлены: на этой машине они не измерялись.'}
    if command == 'verify':
        # 0.1.31: ответ модели — данные, а не действие (И-051, §14 ур. 4).
        return grade_answer(recs, s['retired'], payload)
    if command == 'model':
        # 0.1.31: карточка живой части — что спрашивается и что уже записано (И-051, §14 ур. 4).
        exact(payload, '')
        folder = safe(root, MODELS.rstrip('/'))
        recorded = []
        if folder.is_dir():
            for path in sorted(folder.glob('*.json'))[:32]:
                if not path.is_file():
                    continue
                relpath = path.relative_to(root).as_posix()
                try:
                    graded = grade_answer(recs, s['retired'], parse(path.read_bytes()))
                    recorded.append({'path': relpath, 'bytes': path.stat().st_size,
                                     'model': graded['answer']['model'], 'task': graded['answer']['task'],
                                     'verdict': graded['verdict'], 'counts': graded['counts']})
                except (Refusal, OSError) as exc:
                    recorded.append({'path': relpath, 'bytes': path.stat().st_size,
                                     'verdict': 'unreadable', 'why': getattr(exc, 'code', 'io_or_data')})
        failed = [r for r in recorded if r['verdict'] != 'pass']
        return {'live': False, 'writes': False,
                'tasks': list(MODEL_TASKS),
                'answer': {'path': MODELS + '*.json',
                           'format': {'model': 'имя среды', 'at': 'время ответа', 'task': 'одна из tasks',
                                      'claims': '[{id, state, text}]'},
                           'who_writes': 'владелец: это его каталог, комплект сюда не пишет'},
                'recorded': recorded, 'count': len(recorded),
                'levels': {'3_read_by_model': 'not run',
                           '4_behavior_checked': 'not run' if not recorded else 'fail' if failed else 'pass',
                           '5_behavior_repeatable': 'not run'},
                'proven': {'live_call': False, 'answer_graded': bool(recorded)},
                'note': 'Комплект модель не вызывает: он проверяет записанный ответ. Число записей — '
                        'сколько ответов оценил, а не сколько раз модель работала.'}
    if command == 'rights':
        # 0.1.29: границы доступа к проекту — кто читает и кто пишет (И-049, §11).
        exact(payload, '')
        foreign = foreign_files(root)
        measured = []
        for path in sorted(TARGETS):
            full = Path(root) / path
            if full.is_file():
                info = full.stat()
                measured.append({'path': path, 'bytes': info.st_size,
                                 'mode': None if os.name == 'nt' else oct(stat.S_IMODE(info.st_mode)),
                                 'world_writable': None if os.name == 'nt' else bool(info.st_mode & stat.S_IWOTH)})
        return {'reads': sorted([BASE + n for n in FILES] + [STATE, CHECKS, ENTRY, LOCAL + '**', MODELS + '**']),
                'inputs': {CHECKS: 'входящие журналы для операции merge',
                           MODELS + '*.json': 'записанные ответы модели для model и verify'},
                'files': measured,
                'write_paths': sorted(TARGETS),
                'never': 'всё, что вне reads и writes: содержимое не читается, файлы не меняются',
                'roles': {'writer': 'комплект — единственный, кто пишет, и только в закрытый список write_paths',
                          'reader': 'любой процесс, у которого есть файл; комплект читателей не различает',
                          'foreign': 'чужая запись в служебном каталоге не читается и останавливает изменения'},
                'foreign': foreign,
                'blocks_writes': bool(foreign),
                'writes': False,
                'note': 'Права объявлены данными, а не подразумеваются устройством кода. Объявление — не факт: '
                        'что запись действительно возможна, измеряет команда access. Путей записи десять: '
                        'с 0.1.35 в список входит ответ калибровки (local/calibration/answers.json).'}
    if command == 'list':
        need(not drift and not issues, 'ambiguous', 'Нельзя объявить действующим набор с отклонениями или конфликтами.', {'drift': drift, 'conflicts': issues})
        return {'project_revision': s['revision'], 'active': [] if s['retired'] else effective(recs, target),
                'contracts': [e for e in recs.values() if e['kind']=='contract' and e['state']=='active' and not s['retired'] and (target is None or within(target,e['scope']))]}
    if command == 'history':
        return {'decisions': s['decisions']}
    if command == 'removed':
        # 0.1.20: след удаления виден, а содержимого уже нет (И-040, §9.4).
        return {'removed': s.get('tombstones', []), 'count': len(s.get('tombstones', [])),
                'writes': False,
                'note': 'Следы удаления: идентификатор, вид, область, заголовок, время, причина и ревизия. '
                        'Содержимое удалённой записи не сохраняется.'}
    raise Refusal('command', 'Неизвестная команда.')


# --- 0.1.7: карточка среды GitHub Copilot / VS Code (адаптер, И-027) ----------------
# Отличие от Kilo: вход комплекта у Copilot не рекомендованный, а нижний в своей группе, и часть
# поверхностей его не читает вовсе. Источники сверены 18.11.2026:
#   https://docs.github.com — repository custom instructions, path-specific .instructions.md, порядок
#   https://github.blog/changelog/2025-08-28-copilot-coding-agent-now-supports-agents-md-custom-instructions/
#   https://startdebugging.net/2026/09/... — сводка по поверхностям и оговорка CLI об отсутствии порядка
ADAPTERS['copilot'] = {
    'name': 'copilot',
    'title': 'GitHub Copilot / VS Code',
    'entry': ENTRY,
    'entry_recommended': '.github/copilot-instructions.md',
    'entry_shared': False,
    'entry_fallbacks': ['CLAUDE.md', 'GEMINI.md'],
    'priority': {'tier': 'repository', 'rank': 3, 'of': 5, 'order': [
        {'rank': 1, 'source': 'personal instructions', 'ours': False},
        {'rank': 2, 'source': '.github/instructions/**/*.instructions.md (applyTo)', 'ours': False},
        {'rank': 3, 'source': '.github/copilot-instructions.md', 'ours': False},
        {'rank': 4, 'source': 'AGENTS.md (agent instructions)', 'ours': True},
        {'rank': 5, 'source': 'organization custom instructions', 'ours': False}],
        'note': 'Все применимые наборы передаются модели; старшинство решает конфликт, а не убирает проигравшего.'},
    'sources': ['.github/copilot-instructions.md', '.github/instructions', '.github/agents',
                '.github/prompts', '.github/skills', '.vscode/settings.json', 'CLAUDE.md',
                '.claude/CLAUDE.md', 'GEMINI.md', 'AGENT.md'],
    'never_writes': ['.github/', '.vscode/', 'CLAUDE.md', 'GEMINI.md'],
    'environment_facts': {'instructions_are_prose_not_enforced_rules': True,
                          'path_specific_files_require_applyTo_frontmatter': True,
                          'cli_defines_no_general_precedence_order': True,
                          'agents_md_outside_workspace_root_off_by_default': True},
    'coverage': {'reads_agents_md': ['Copilot cloud agent', 'Copilot code review (GitHub.com)',
                                     'Copilot CLI', 'Copilot Chat in VS Code'],
                 'coverage_gap': ['Copilot Chat on github.com', 'inline suggestions'],
                 'reads_repo_wide_file': 'all surfaces supporting custom instructions at all'},
    'not_proven': ['auto-discovery', 'content_was_read', 'behaviour_with_model'],
    'discovery_proven': False,
}


# --- 0.1.8: заглушки остальных сред (И-028) -----------------------------------------
# Среда объявлена по имени, но её факты не сверялись и адаптер не реализован. Заглушка отвечает
# ровно это и ничего больше: у неё нет входа, старшинства, источников и покрытия. Отличие от
# «неизвестной среды» в том, что имя известно, а обещаний нет ни одного.
STUB_ENVIRONMENTS = (('claude', 'Claude Code'), ('cursor', 'Cursor'), ('antigravity', 'Antigravity'))
for _name, _title in STUB_ENVIRONMENTS:
    ADAPTERS[_name] = {
        'name': _name,
        'title': _title,
        'status': 'stub',
        'entry': None,
        'entry_recommended': None,
        'entry_shared': None,
        'sources': [],
        'never_writes': [],
        'environment_facts': {},
        'coverage': {'reads_agents_md': [], 'coverage_gap': ['не измерялось: адаптер не реализован']},
        'not_proven': ['adapter_implemented', 'auto-discovery', 'content_was_read', 'behaviour_with_model'],
        'discovery_proven': False,
        'facts_checked_at': None,
        'note': 'Заглушка: среда объявлена по имени; факты не сверялись, адаптер не реализован. '
                'Вход не создаётся, конфигурация среды не читается.',
    }
ADAPTERS['kilo'].update(status='documented', facts_checked_at='2026-11-18')
ADAPTERS['copilot'].update(status='documented', facts_checked_at='2026-11-18')


# --- 0.1.9: наблюдатель отделён от условий (И-029, решение владельца Б) ------------------
# Условия наблюдения сравниваются точно, как и прежде. Наблюдатель — редактор, расширение, их версии и
# профиль — это происхождение записи, а не её содержание: он выведен из сравнения так же, как место
# улики в 0.1.5. Причина измерена стендом И-028: одно событие, увиденное Kilo и Copilot, давало две
# записи, потому что environment сравнивался целиком.
CONDITIONS = ('os', 'mode', 'model', 'permissions')
OBSERVER = ('editor', 'editor_version', 'extension', 'extension_version', 'profile')


def main(argv=None):
    cli = argparse.ArgumentParser(description='Контракт проекта • офлайн • без внешних модулей')
    cli.add_argument('--version', action='version', version=VERSION)
    cli.add_argument('--lab', required=True, help='абсолютный путь к отдельному корню лаборатории')
    cli.add_argument('--project', default='.', help='папка проекта относительно лаборатории; обязательна для проектных операций')
    cli.add_argument('--target', help='относительный путь для фильтра list')
    cli.add_argument('command', choices=('status', 'list', 'metrics', 'rights', 'access', 'system', 'model', 'verify', 'layout', 'calibrate', 'history', 'removed', 'updates', 'pending', 'operations', 'inventory', 'adapter', 'brief', 'identity', 'discovery', 'entry', 'repeat', 'session', 'due', 'plan', 'apply'))
    args = cli.parse_args(argv)
    try:
        if args.command in ('session', 'plan', 'apply', 'adapter', 'discovery', 'entry', 'repeat', 'metrics',
                            'verify', 'calibrate'):
            # 0.1.11: adapter принимает {"name": ...} тем же способом, что plan и apply.
            raw = sys.stdin.buffer.read(MAX_BYTES+1)
            data = parse(raw) if raw.strip() else {}
        else:
            data = {}
        out = dispatch(labroot(args.lab), args.project, args.command, data, args.target)
        code = 2 if out.get('outcome') == 'partial' or out.get('health') in ('partial', 'attention') else 0
    except Refusal as exc:
        out, code = {'error': exc.code, 'message': str(exc), 'details': exc.details}, 2
    except (OSError, ValueError, UnicodeError, RecursionError) as exc:
        out, code = {'error': 'io_or_data', 'message': str(exc), 'next': 'Не считать успешным. Проверьте pending.'}, 2
    sys.stdout.buffer.write(encode(out))
    return code


if __name__ == '__main__':
    raise SystemExit(main())
