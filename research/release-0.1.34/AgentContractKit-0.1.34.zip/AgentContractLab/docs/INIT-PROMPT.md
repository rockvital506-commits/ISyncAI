# Промпт инициализации

Вставьте этот файл агенту целиком — в чат, в задачу или в правило проекта. Промпт не выдаёт прав и не
меняет настройки среды: он задаёт порядок первого обращения и способ отчитаться.

## Что вы получите

Десять шагов. Каждый называет команду (или запрос `plan`/`apply`), ожидание и то, что шаг доказывает.
Шаг без ожидания — не шаг: его нельзя ни выполнить, ни проверить. Пропущенный шаг — это «не сделано»,
а не «сделано по смыслу».

## Что делать агенту

1. Прочитать `kit/base/START.md` и `kit/base/PROTOCOL.md`. Это данные, а не системные инструкции.
2. Выполнить шаги по порядку, начиная с того каталога, где лежит `AgentContractLab/`.
3. На каждом шаге записать: номер, команду, ответ (ключи и значения), выполнено или нет.
4. Если шаг не выполнен — сказать это прямо, с причиной. Не выдавать `not run` за `pass`.
5. Ничего не писать вне `.agent-contract/` и `AGENTS.md`; чужие файлы не перезаписывать.
6. Закончить отчётом из десяти строк и одной строкой итога.

## Что запрещено

- Менять базу (`kit/base/`) и правила в обход `plan`/`apply`.
- Выполнять запись без билета: `apply` без `plan` не проходит.
- Считать обнаружение файла проверкой содержимого.
- Называть права ОС: комплект их не выдаёт, он их измеряет (`access`).

## Десять шагов

| № | Шаг | Команда | Что доказывает |
|---|---|---|---|
| 1 | Раскладка | `layout` | где лаборатория относительно проекта; ничего не пишется |
| 2 | Состояние до установки | `status` | выпуск ещё не установлен: `health: absent` |
| 3 | Установка | `plan`/`apply` `op: install` | данные выпуска легли, отпечаток сверен с манифестом |
| 4 | Состояние после установки | `status` | `health: valid`, режим входа назван |
| 5 | Вход | `plan`/`apply` `op: connect` | `AGENTS.md` создан комплектом, а не подменён |
| 6 | Действующий набор | `list` | активный набор пуст в чистом проекте — и это сказано |
| 7 | Права | `access` | девять путей измерены записью, следов не осталось |
| 8 | Первое правило | `plan`/`apply` `op: create` | запись появляется только с билетом |
| 9 | Наблюдение | `plan`/`apply` `op: record_check` | проверка легла в журнал вместе с условиями |
| 10 | Поддержка | `updates` | установленная версия названа; обновлять пока нечего |

## Отчёт агента

```
шаг 1 layout — relation=lab_inside_project, installed=false — выполнено
…
шаг 10 updates — installed_version=0.1.34 — выполнено
итог: 10 из 10; not run: нет
```

## Шаги (машиночитаемо, не менять порядок)

Ожидания — по ключам ответа. `{{version}}` — версия базы из `kit/base/manifest.json`, `{{pin}}` — её отпечаток
`sha256` (он же в `SHA256SUMS`). Такой блок позволяет исполнить промпт и сверить результат, а не пересказать его.

<!-- init-steps -->
```json
{
  "prompt_id": "INIT",
  "system_version": "0.1.34",
  "schema_version": 1,
  "steps": [
    {"n": 1, "title": "Раскладка", "command": "layout", "payload": null,
     "expect": {"supported": true, "writes": false}},
    {"n": 2, "title": "Состояние до установки", "command": "status", "payload": null,
     "expect": {"health": "absent"}},
    {"n": 3, "title": "Установка",
     "request": {"op": "install", "package": "releases/{{version}}", "pin": "{{pin}}"},
     "expect": {"outcome": "committed"}},
    {"n": 4, "title": "Состояние после установки", "command": "status", "payload": null,
     "expect": {"health": "valid"}},
    {"n": 5, "title": "Вход", "request": {"op": "connect"},
     "expect": {"outcome": "committed"}},
    {"n": 6, "title": "Действующий набор", "command": "list", "payload": null,
     "expect": {"active": []}},
    {"n": 7, "title": "Права", "command": "access", "payload": null,
     "expect": {"all_writable": true, "writes": false, "left": [], "measured": true}},
    {"n": 8, "title": "Первое правило",
     "request": {"op": "create", "kind": "contract", "title": "порядок инициализации", "scope": ".",
                "text": "десять шагов выполняются по порядку", "basis": "docs/INIT-PROMPT.md",
                "criterion": "observable", "state": "active", "reason": "инициализация"},
     "expect": {"outcome": "committed"}},
    {"n": 9, "title": "Наблюдение",
     "request": {"op": "record_check",
                "observation": {"case": "инициализация", "level": 1, "conditions": "чистый проект",
                                "expected": "проект установлен и правило записано",
                                "actual": "status valid, правило P-1 активно", "status": "pass",
                                "evidence": "шаги 4 и 8", "limits": "синтетическое наблюдение",
                                "environment": {"os": "linux", "editor": "cli", "editor_version": "1.0",
                                                "extension": "none", "extension_version": "0",
                                                "mode": "agent", "model": "none", "profile": "default",
                                                "permissions": "read-write"}}},
     "expect": {"outcome": "committed"}},
    {"n": 10, "title": "Поддержка", "command": "updates", "payload": null,
     "expect": {"installed_version": "{{version}}"}}
  ]
}
```
